# Yujin-DAppBridge（Android App-Plus 原生插件源码）

本目录是 Android 原生插件源码工程，包含 `Yujin-DAppBridge` 与 `Yujin-BiometricVault` 两个 UniModule。它不是可直接复制到 `nativeplugins` 使用的已编译插件。

## 1. HBuilderX 5.34 对应的构建环境

请使用同一套版本，不要混用不同 HBuilderX 版本的运行库：

- HBuilderX：5.34（官方当前正式包标识：`5.34.2026102909`；以你安装的完整版本号为准）
- 对应的 DCloud Android App 离线 SDK：必须与 HBuilderX 版本完全匹配
- JDK：17
- Gradle：8.14.3
- Android Gradle Plugin：8.12.0
- Android SDK Platform：36
- Android Build Tools：36.0.0

DCloud 官方从 HBuilderX 4.81 起的 Android 工程基线要求 compileSdk 36、Build Tools 36.0.0、Gradle 8.14.3、AGP 8.12.0。本工程已按该基线适配。参考：

- Android 离线 SDK 下载： https://nativesupport.dcloud.net.cn/AppDocs/download/android.html
- Android 离线工程配置： https://nativesupport.dcloud.net.cn/AppDocs/usesdk/android.html

## 2. 准备 DCloud SDK AAR

从你安装的 HBuilderX 5.34 对应的 Android App 离线 SDK 中复制：

`uniapp-v8-release.aar`

放到本工程：

`android/libs/uniapp-v8-release.aar`

如果 `android/libs/` 不存在，请自行创建。该 AAR 提供 `UniModule`、`UniJSMethod`、`UniJSCallback` 等 DCloud API。由于 AGP 不允许库模块直接依赖本地 AAR 再产出 AAR，构建脚本会先从已校验的 DCloud AAR 提取 `classes.jar`/嵌入 JAR，再将这些 JAR 声明为 `compileOnly`；宿主 uni-app 运行时负责提供实际运行类。严禁使用空文件、伪造 stub 或其他版本 AAR。

## 3. 编译

在 `android/` 目录执行，确保 `JAVA_HOME` 指向 JDK 17，且 Gradle 版本为 8.14.3：

```bash
gradle --version
gradle clean extractDcloudCompileJars assembleRelease
```

构建产物：

`android/build/outputs/aar/android-release.aar`

如果缺少匹配的 DCloud AAR，`verifyDcloudSdk` 会在预构建阶段给出明确提示。若报 Android SDK Platform 36 或 Build Tools 36.0.0 缺失，请在 Android SDK Manager 安装对应组件。

## 4. 集成到 uni-app

在钱包项目根目录创建：

`nativeplugins/Yujin-DAppBridge/`

将本目录的 `package.json` 复制到该目录，并创建 `nativeplugins/Yujin-DAppBridge/android/`，将编译产物复制为：

`nativeplugins/Yujin-DAppBridge/android/Yujin-DAppBridge-release.aar`

随后在 HBuilderX 的 App 原生插件配置中选择该本地插件，重新制作自定义基座。仅复制源码目录或创建 `nativeplugins` 文件夹不代表插件已集成。

## 5. 当前安全边界

- 仅 Android App-Plus 原生实现；iOS、H5、小程序不使用此原生桥。
- HTTPS 且无 URL 用户名/密码；会话绑定精确 origin。
- AndroidX WebMessageListener 检查 `sourceOrigin` 和 `isMainFrame`。
- 钱包账户披露需要用户明确确认；可撤销授权。
- 只开放受限只读 JSON-RPC。
- `eth_sendTransaction`、`personal_sign`、`eth_signTypedData*` 等交易/签名方法仍明确拒绝。
- AAR 编译成功不等于钱包已集成或真机运行通过；必须使用 HBuilderX 5.34 自定义基座完成 Android 真机回归。
