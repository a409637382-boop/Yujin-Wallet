package com.yujin.dappbridge;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.security.keystore.KeyInfo;
import android.util.Base64;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.alibaba.fastjson.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKeyFactory;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import io.dcloud.feature.uniapp.annotation.UniJSMethod;
import io.dcloud.feature.uniapp.bridge.UniJSCallback;
import io.dcloud.feature.uniapp.common.UniModule;

/**
 * Android Keystore-backed, per-account AES-256-GCM vault.
 * The Keystore key is non-exportable and requires strong biometric auth for each use.
 * This module never persists plaintext private keys and never signs blockchain transactions.
 */
public final class BiometricVaultModule extends UniModule {
    private static final String STORE = "AndroidKeyStore";
    private static final String PREFIX = "yjc_bio_v1_";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    // A single process-wide prompt prevents overlapping biometric CryptoObjects.
    private static final AtomicBoolean AUTH_ACTIVE = new AtomicBoolean(false);

    @UniJSMethod(uiThread = true)
    public void biometricStatus(JSONObject options, UniJSCallback callback) {
        Activity activity = activity();
        if (activity == null || !(activity instanceof FragmentActivity)) {
            invoke(callback, error("ACTIVITY_UNSUPPORTED", "当前自定义基座未提供 AndroidX FragmentActivity，无法安全启动生物识别"));
            return;
        }
        int result = BiometricManager.from(activity).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
        JSONObject out = new JSONObject();
        boolean noHardware = result == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE;
        boolean unsupported = result == BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED;
        // Only SUCCESS proves that a strong biometric is currently enrolled and usable.
        // HW_UNAVAILABLE may indicate hardware exists, but does not prove enrollment.
        boolean enrolled = result == BiometricManager.BIOMETRIC_SUCCESS;
        out.put("available", enrolled);
        // A temporary hardware outage is distinct from a device with no biometric hardware.
        out.put("hardware", !noHardware && !unsupported);
        out.put("enrolled", enrolled);
        out.put("strong", enrolled);
        out.put("code", result);
        out.put("source", "android-keystore-biometricprompt");
        invoke(callback, out);
    }

    @UniJSMethod(uiThread = true)
    public void wrapPrivateKey(JSONObject options, UniJSCallback callback) {
        Activity activity = activity();
        String address = account(options);
        String privateKey = options == null ? "" : options.getString("privateKey");
        if (!validAddress(address) || privateKey == null || !privateKey.matches("(?i)[0-9a-f]{64}")) {
            invoke(callback, error("INPUT_INVALID", "账户地址或私钥格式无效")); return;
        }
        if (!(activity instanceof FragmentActivity)) {
            invoke(callback, error("ACTIVITY_UNSUPPORTED", "当前 Android Activity 不支持安全生物识别")); return;
        }
        String keyAlias = null;
        try {
            KeyStore store = loadStore();
            keyAlias = alias(activity, address);
            final String alias = keyAlias;
            if (store.containsAlias(alias) || store.containsAlias(legacyAlias(activity, address))) {
                invoke(callback, error("ALIAS_EXISTS", "该账户已绑定生物识别；如需重新绑定，请先通过钱包密码解除旧绑定")); return;
            }
            SecretKey key = generateKey(alias);
            ensureHardwareBacked(key);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            cipher.updateAAD(aad(address));
            authenticate((FragmentActivity) activity, cipher, "启用钱包指纹解锁", new CryptoResult() {
                @Override public void success(Cipher authenticatedCipher) {
                    byte[] plain = privateKey.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8);
                    try {
                        byte[] encrypted = authenticatedCipher.doFinal(plain);
                        JSONObject out = new JSONObject();
                        out.put("ok", true);
                        out.put("v", 1);
                        out.put("account", address);
                        out.put("iv", Base64.encodeToString(authenticatedCipher.getIV(), Base64.NO_WRAP));
                        out.put("ciphertext", Base64.encodeToString(encrypted, Base64.NO_WRAP));
                        invoke(callback, out);
                        java.util.Arrays.fill(encrypted, (byte) 0);
                    } catch (Exception e) {
                        deleteAlias(alias);
                        invoke(callback, error("ENCRYPT_FAILED", "Keystore 加密失败，请保留密码解锁方式"));
                    } finally { java.util.Arrays.fill(plain, (byte) 0); }
                }
                @Override public void failure(String code, String message) { deleteAlias(alias); invoke(callback, error(code, message)); }
            });
        } catch (Exception e) {
            if (keyAlias != null) deleteAlias(keyAlias);
            invoke(callback, error("KEYSTORE_FAILED", "无法创建硬件保护密钥；请检查设备安全锁屏和生物识别设置"));
        }
    }

    @UniJSMethod(uiThread = true)
    public void unwrapPrivateKey(JSONObject options, UniJSCallback callback) {
        Activity activity = activity();
        String address = account(options);
        String envelopeAccount = options == null ? "" : options.getString("account");
        String ivText = options == null ? "" : options.getString("iv");
        String cipherText = options == null ? "" : options.getString("ciphertext");
        int version = options == null || options.getInteger("v") == null ? 0 : options.getInteger("v");
        if (!validAddress(address) || !address.equalsIgnoreCase(envelopeAccount) || version != 1 || ivText == null || cipherText == null) {
            invoke(callback, error("ENVELOPE_INVALID", "生物识别密文与当前账户不匹配")); return;
        }
        if (!(activity instanceof FragmentActivity)) {
            invoke(callback, error("ACTIVITY_UNSUPPORTED", "当前 Android Activity 不支持安全生物识别")); return;
        }
        try {
            KeyStore store = loadStore();
            String alias = alias(activity, address);
            // Preserve R128 biometric enrollments: try the former URL-safe Base64 alias
            // only when the collision-free hexadecimal alias is not present.
            if (!store.containsAlias(alias)) {
                String legacy = legacyAlias(activity, address);
                if (store.containsAlias(legacy)) alias = legacy;
                else { invoke(callback, error("KEY_MISSING", "设备安全密钥不存在或已因指纹变更失效，请使用钱包密码解锁后重新绑定")); return; }
            }
            if (ivText.length() > 64 || cipherText.length() > 256) { invoke(callback, error("ENVELOPE_INVALID", "生物识别密文长度异常")); return; }
            byte[] iv = Base64.decode(ivText, Base64.NO_WRAP);
            byte[] ciphertext = Base64.decode(cipherText, Base64.NO_WRAP);
            if (iv.length != 12 || ciphertext.length != 80) { invoke(callback, error("ENVELOPE_INVALID", "生物识别密文长度异常")); return; }
            SecretKey key = (SecretKey) store.getKey(alias, null);
            ensureHardwareBacked(key);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
            cipher.updateAAD(aad(address));
            authenticate((FragmentActivity) activity, cipher, "验证身份并解锁钱包", new CryptoResult() {
                @Override public void success(Cipher authenticatedCipher) {
                    byte[] plain = null;
                    try {
                        plain = authenticatedCipher.doFinal(ciphertext);
                        String privateKey = new String(plain, StandardCharsets.UTF_8);
                        if (!privateKey.matches("(?i)[0-9a-f]{64}")) throw new IllegalStateException("decrypted key format invalid");
                        JSONObject out = new JSONObject(); out.put("ok", true); out.put("privateKey", privateKey.toLowerCase(Locale.ROOT));
                        invoke(callback, out);
                    } catch (Exception e) {
                        invoke(callback, error("DECRYPT_FAILED", "生物识别密钥解封失败；请使用钱包密码解锁"));
                    } finally {
                        // Clear the mutable plaintext byte buffer on every exit path.
                        if (plain != null) java.util.Arrays.fill(plain, (byte) 0);
                    }
                }
                @Override public void failure(String code, String message) { invoke(callback, error(code, message)); }
            });
        } catch (Exception e) {
            if (hasCauseNamed(e, "KeyPermanentlyInvalidatedException") || hasCauseNamed(e, "UnrecoverableKeyException")) {
                invoke(callback, error("KEY_INVALIDATED", "设备指纹或安全策略已变化，原指纹密钥不可用；请使用钱包密码验证后，在账户管理中修复绑定"));
            } else {
                invoke(callback, error("KEYSTORE_FAILED", "安全密钥暂不可用；请使用钱包密码解锁，稍后可在账户管理中修复绑定"));
            }
        }
    }

    @UniJSMethod(uiThread = true)
    public void deleteBiometricKey(JSONObject options, UniJSCallback callback) {
        Activity activity = activity();
        String address = account(options);
        if (activity == null || !validAddress(address)) { invoke(callback, error("INPUT_INVALID", "账户地址无效")); return; }
        try {
            KeyStore store = loadStore();
            String alias = alias(activity, address);
            String legacy = legacyAlias(activity, address);
            if (store.containsAlias(alias)) store.deleteEntry(alias);
            if (store.containsAlias(legacy)) store.deleteEntry(legacy);
            // Keystore deletion is a prerequisite for removing wallet metadata.
            // Read back both current and legacy aliases before reporting success.
            KeyStore verify = loadStore();
            if (verify.containsAlias(alias) || verify.containsAlias(legacy)) {
                invoke(callback, error("DELETE_INCOMPLETE", "账户指纹安全密钥仍有残留，已阻止删除账户绑定记录"));
                return;
            }
            JSONObject out = new JSONObject(); out.put("ok", true); invoke(callback, out);
        } catch (Exception e) { invoke(callback, error("DELETE_FAILED", "解除生物识别绑定失败")); }
    }

    /**
     * Explicit full-wallet-wipe operation. Deletes every alias owned by this module,
     * including orphaned aliases whose account metadata is no longer available.
     */
    @UniJSMethod(uiThread = true)
    public void deleteAllBiometricKeys(JSONObject options, UniJSCallback callback) {
        Activity activity = activity();
        if (activity == null) { invoke(callback, error("ACTIVITY_UNAVAILABLE", "无法访问 Android Keystore")); return; }
        try {
            KeyStore store = loadStore();
            java.util.Enumeration<String> aliases = store.aliases();
            java.util.List<String> owned = new java.util.ArrayList<>();
            while (aliases.hasMoreElements()) {
                String candidate = aliases.nextElement();
                if (candidate != null && candidate.startsWith(PREFIX)) owned.add(candidate);
            }
            for (String candidate : owned) store.deleteEntry(candidate);
            // Read back: never report success while any plugin-owned alias remains.
            KeyStore verify = loadStore();
            java.util.Enumeration<String> remaining = verify.aliases();
            while (remaining.hasMoreElements()) {
                String candidate = remaining.nextElement();
                if (candidate != null && candidate.startsWith(PREFIX)) {
                    invoke(callback, error("DELETE_INCOMPLETE", "仍有指纹安全密钥未能清除")); return;
                }
            }
            JSONObject out = new JSONObject(); out.put("ok", true); out.put("deleted", owned.size()); invoke(callback, out);
        } catch (Exception e) { invoke(callback, error("DELETE_ALL_FAILED", "清理孤立指纹安全密钥失败")); }
    }

    private interface CryptoResult { void success(Cipher cipher); void failure(String code, String message); }

    private void authenticate(FragmentActivity activity, Cipher cipher, String title, CryptoResult result) {
        if (!AUTH_ACTIVE.compareAndSet(false, true)) {
            result.failure("AUTH_BUSY", "已有生物识别操作正在进行，请稍候");
            return;
        }
        Executor executor = ContextCompat.getMainExecutor(activity);
        Handler handler = new Handler(Looper.getMainLooper());
        AtomicBoolean finished = new AtomicBoolean(false);
        final BiometricPrompt[] promptRef = new BiometricPrompt[1];
        Runnable timeout = () -> {
            if (finished.compareAndSet(false, true)) {
                try { if (promptRef[0] != null) promptRef[0].cancelAuthentication(); } catch (Exception ignored) {}
                AUTH_ACTIVE.set(false);
                result.failure("AUTH_TIMEOUT", "生物识别验证超时，请使用钱包密码解锁");
            }
        };
        BiometricPrompt prompt = new BiometricPrompt(activity, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationError(int code, CharSequence message) {
                if (!finished.compareAndSet(false, true)) return;
                handler.removeCallbacks(timeout);
                AUTH_ACTIVE.set(false);
                // Preserve AndroidX terminal categories so lockout is not mistaken
                // for an ordinary bad scan and users are directed to password recovery.
                String errorCode = "AUTH_FAILED";
                String errorMessage = message == null ? "生物识别未通过" : message.toString();
                if (code == BiometricPrompt.ERROR_LOCKOUT) {
                    errorCode = "BIOMETRIC_LOCKOUT";
                    errorMessage = "指纹验证暂时锁定，请使用钱包密码解锁，稍后再试";
                } else if (code == BiometricPrompt.ERROR_LOCKOUT_PERMANENT) {
                    errorCode = "BIOMETRIC_LOCKOUT_PERMANENT";
                    errorMessage = "指纹验证已被系统永久锁定，请使用钱包密码解锁，并检查设备安全设置";
                } else if (code == BiometricPrompt.ERROR_USER_CANCELED ||
                           code == BiometricPrompt.ERROR_NEGATIVE_BUTTON ||
                           code == BiometricPrompt.ERROR_CANCELED) {
                    errorCode = "AUTH_CANCELED";
                    errorMessage = "已取消指纹验证，请使用钱包密码解锁";
                }
                result.failure(errorCode, errorMessage);
            }
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult auth) {
                if (!finished.compareAndSet(false, true)) return;
                handler.removeCallbacks(timeout);
                // A prompt callback can race Activity recreation/background teardown.
                // Never release a Keystore CryptoObject through a callback owned by a
                // destroyed or superseded Activity; the JS page must start a fresh prompt.
                Activity currentActivity = BiometricVaultModule.this.activity();
                if (activity.isFinishing() ||
                    (Build.VERSION.SDK_INT >= 17 && activity.isDestroyed()) ||
                    currentActivity != activity) {
                    AUTH_ACTIVE.set(false);
                    result.failure("AUTH_ACTIVITY_GONE", "钱包界面已重建或退出，请返回钱包后重新进行指纹验证");
                    return;
                }
                try {
                    Cipher authenticated = auth.getCryptoObject() == null ? null : auth.getCryptoObject().getCipher();
                    if (authenticated == null) { AUTH_ACTIVE.set(false); result.failure("CRYPTO_OBJECT_MISSING", "系统未返回受保护的密码学操作"); return; }
                    try { result.success(authenticated); }
                    finally { AUTH_ACTIVE.set(false); }
                } catch (Exception e) { AUTH_ACTIVE.set(false); result.failure("AUTH_FAILED", "生物识别验证结果无效"); }
            }
            @Override public void onAuthenticationFailed() { /* Keep prompt open; no secret is released. */ }
        });
        promptRef[0] = prompt;
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("使用已录入的强生物识别验证本机钱包密钥")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("取消")
            .build();
        try {
            handler.postDelayed(timeout, 45000L);
            prompt.authenticate(info, new BiometricPrompt.CryptoObject(cipher));
        } catch (Exception e) {
            handler.removeCallbacks(timeout);
            if (finished.compareAndSet(false, true)) { AUTH_ACTIVE.set(false); result.failure("AUTH_START_FAILED", "无法启动系统生物识别验证"); }
        }
    }

    private static SecretKey generateKey(String alias) throws Exception {
        if (Build.VERSION.SDK_INT < 23) throw new IllegalStateException("Android Keystore AES-GCM requires API 23+");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, STORE);
        KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .setUserAuthenticationRequired(true);
        if (Build.VERSION.SDK_INT >= 24) builder.setInvalidatedByBiometricEnrollment(true);
        if (Build.VERSION.SDK_INT >= 30) builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        else builder.setUserAuthenticationValidityDurationSeconds(-1);
        generator.init(builder.build());
        return generator.generateKey();
    }

    private static void ensureHardwareBacked(SecretKey key) throws Exception {
        if (key == null) throw new IllegalStateException("Keystore key missing");
        SecretKeyFactory factory = SecretKeyFactory.getInstance(key.getAlgorithm(), STORE);
        KeyInfo info = (KeyInfo) factory.getKeySpec(key, KeyInfo.class);
        if (info == null || !info.isInsideSecureHardware()) throw new IllegalStateException("Keystore key is not hardware-backed");
        if (Build.VERSION.SDK_INT >= 31) {
            int level = info.getSecurityLevel();
            if (level != KeyProperties.SECURITY_LEVEL_TRUSTED_ENVIRONMENT && level != KeyProperties.SECURITY_LEVEL_STRONGBOX) {
                throw new IllegalStateException("Keystore key is not protected by TEE or StrongBox");
            }
        }
    }
    private static void deleteAlias(String alias) {
        try { KeyStore store = loadStore(); if (store.containsAlias(alias)) store.deleteEntry(alias); } catch (Exception ignored) {}
    }

    private static KeyStore loadStore() throws Exception {
        KeyStore store = KeyStore.getInstance(STORE); store.load(null); return store;
    }
    private Activity activity() {
        try { return mUniSDKInstance != null && mUniSDKInstance.getContext() instanceof Activity ? (Activity) mUniSDKInstance.getContext() : null; }
        catch (Exception e) { return null; }
    }
    private static String account(JSONObject options) { return options == null ? "" : String.valueOf(options.getString("account") == null ? "" : options.getString("account")).toLowerCase(Locale.ROOT); }
    private static boolean validAddress(String address) { return address != null && address.matches("0x[0-9a-f]{40}"); }
    private static byte[] aad(String address) { return ("YJC-BIOMETRIC-VAULT:v1:" + address.toLowerCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8); }
    private static String alias(Context context, String address) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest((context.getPackageName() + ":" + address.toLowerCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8));
        // Hex encoding is injective; the previous URL-safe Base64 character replacement
        // could theoretically collide with ordinary 'a'/'b' characters in the digest.
        StringBuilder hex = new StringBuilder(digest.length * 2);
        for (byte value : digest) hex.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        return PREFIX + hex.toString();
    }
    private static String legacyAlias(Context context, String address) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest((context.getPackageName() + ":" + address.toLowerCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8));
        return PREFIX + Base64.encodeToString(digest, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING).replace('-', 'a').replace('_', 'b');
    }
    private static boolean hasCauseNamed(Throwable error, String simpleName) {
        Throwable current = error;
        for (int i = 0; current != null && i < 12; i++, current = current.getCause()) {
            if (simpleName.equals(current.getClass().getSimpleName())) return true;
        }
        return false;
    }
    private static JSONObject error(String code, String message) { JSONObject out = new JSONObject(); out.put("ok", false); out.put("code", code); out.put("message", message); return out; }
    private static void invoke(UniJSCallback callback, JSONObject value) { if (callback != null) callback.invoke(value); }
}
