package com.yujin.dappbridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebStorageCompat;
import androidx.webkit.WebViewFeature;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import okhttp3.ConnectionPool;
import okhttp3.Dns;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import java.lang.ref.WeakReference;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Dedicated Android WebView host. The app's generic uni web-view event channel is not trusted.
 * Only AndroidX WebMessageListener sourceOrigin + isMainFrame can reach the protocol handler.
 * This first native bridge intentionally supports account disclosure only; signing and tx methods
 * are rejected until transaction decoding/confirmation is integrated and independently audited.
 */
public final class DappBrowserActivity extends Activity {
    private static final Map<String, WeakReference<DappBrowserActivity>> ACTIVITIES = new ConcurrentHashMap<>();
    private static final Map<String, PendingConnect> PENDING = new ConcurrentHashMap<>();
    private static final Map<String, PendingTransaction> PENDING_TRANSACTIONS = new ConcurrentHashMap<>();
    private static final Object PENDING_TRANSACTION_LOCK = new Object();
    private static final Object PENDING_CONNECT_LOCK = new Object();
    private static final int MAX_MESSAGE = 8192;
    private static final int MAX_REQUESTS = 128;
    private static final long MAX_SKEW_MS = 30000L;
    private static final long CONNECT_TIMEOUT_MS = 60000L;
    private static final long TRANSACTION_PREVIEW_TIMEOUT_MS = 90000L;
    private static final int MAX_PENDING_TRANSACTIONS = 32;
    private static final int MAX_PENDING_TRANSACTIONS_PER_SESSION = 4;
    private static final int MAX_PENDING_CONNECTS = 32;
    private static final int MAX_RPC_RESPONSE = 262144;
    // Process-wide bound: at most 2 active RPC workers plus 12 queued tasks across ALL
    // DApp Activities. newFixedThreadPool() uses an unbounded queue and allowed hostile
    // pages opened in multiple sessions to accumulate work despite the per-session cap.
    private static final int MAX_RPC_WORKERS = 2;
    private static final int MAX_RPC_QUEUE = 12;
    private static final ThreadPoolExecutor RPC_EXECUTOR = new ThreadPoolExecutor(
        MAX_RPC_WORKERS, MAX_RPC_WORKERS, 0L, TimeUnit.MILLISECONDS,
        new ArrayBlockingQueue<Runnable>(MAX_RPC_QUEUE),
        new ThreadPoolExecutor.AbortPolicy());
    // Process-scoped salt: rotation keeps the same profile; a process restart never reopens it.
    private static final String PROCESS_PROFILE_EPOCH = randomHex(8);

    private String sessionId;
    private String expectedOrigin;
    private String chainId;
    private String chainName;
    private String rpcUrl;
    private String nonce;
    private long openedAt;
    private String approvedAccount = "";
    private final Set<String> seenIds = new HashSet<>();
    private int requestCount = 0;
    private int pendingRpc = 0;
    // Invalidates asynchronous RPC completions when the document/session/authorization changes.
    private long rpcEpoch = 0L;
    private boolean mainFrameStarted = false;
    // The native bridge accepts messages only after the current main document has finished.
    // This closes the transition window in which a same-origin old document could still
    // have queued a WebMessageListener callback after navigation began.
    private volatile boolean pageReady = false;
    // A fatal browser/security condition must revoke bridge authority before UI confirmation.
    private boolean securityTerminationRequested = false;
    private WebView webView;
    private Profile dappProfile;
    private String dappProfileName;
    private TextView titleView;
    private TextView pageStatusView;
    private String pageTitle = "";
    private String pageError = "";
    private Button revokeButton;
    private Button backButton;
    private Button forwardButton;
    private Button reloadButton;
    private ProgressBar pageProgress;
    private boolean pageLoading = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final class PendingConnect {
        final WeakReference<DappBrowserActivity> activity;
        final JavaScriptReplyProxy reply;
        final String sessionId;
        final String requestId;
        final String origin;
        final String chainId;
        final Runnable timeout;
        PendingConnect(DappBrowserActivity a, JavaScriptReplyProxy r, String s, String id,
                       String origin, String chainId, Runnable t) {
            activity = new WeakReference<>(a); reply = r; sessionId = s; requestId = id;
            this.origin = origin; this.chainId = chainId; timeout = t;
        }
    }

    private static final class PendingTransaction {
        final WeakReference<DappBrowserActivity> activity;
        final JavaScriptReplyProxy reply;
        final String sessionId;
        final String requestId;
        final String origin;
        final String account;
        final String chainId;
        final Runnable timeout;
        PendingTransaction(DappBrowserActivity a, JavaScriptReplyProxy r, String s, String id,
                           String o, String account, String chain, Runnable t) {
            activity = new WeakReference<>(a); reply = r; sessionId = s; requestId = id;
            origin = o; this.account = account; chainId = chain; timeout = t;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        sessionId = getIntent().getStringExtra("sessionId");
        expectedOrigin = normalizeOrigin(getIntent().getStringExtra("origin"));
        chainId = getIntent().getStringExtra("chainId");
        chainName = getIntent().getStringExtra("chainName");
        rpcUrl = getIntent().getStringExtra("rpcUrl");
        String startUrl = getIntent().getStringExtra("url");
        if (sessionId == null || !sessionId.matches("[a-fA-F0-9]{32}") || expectedOrigin.isEmpty() || chainId == null || !chainId.matches("[1-9][0-9]{0,19}") || !isValidRpcUrl(rpcUrl) || !isAllowedUrl(startUrl)) {
            finish(); return;
        }
        nonce = randomHex(32);
        openedAt = System.currentTimeMillis();
        ACTIVITIES.put(sessionId, new WeakReference<>(this));
        buildUi();
        if (isFinishing() || webView == null) return;
        if (!configureWebView()) return;
        verifyRpcChainThenLoad(startUrl);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(12, 8, 12, 8);
        bar.setBackgroundColor(Color.rgb(245, 248, 252));
        Button close = new Button(this);
        close.setText("关闭");
        close.setOnClickListener(v -> finish());
        backButton = new Button(this);
        backButton.setText("‹");
        backButton.setContentDescription("后退");
        backButton.setEnabled(false);
        backButton.setAlpha(0.45f);
        backButton.setOnClickListener(v -> navigateBack());
        forwardButton = new Button(this);
        forwardButton.setText("›");
        forwardButton.setContentDescription("前进");
        forwardButton.setEnabled(false);
        forwardButton.setAlpha(0.45f);
        forwardButton.setOnClickListener(v -> navigateForward());
        reloadButton = new Button(this);
        reloadButton.setText("↻");
        reloadButton.setContentDescription("刷新页面");
        reloadButton.setOnClickListener(v -> reloadOrStop());
        revokeButton = new Button(this);
        revokeButton.setText("撤销授权");
        revokeButton.setEnabled(false);
        revokeButton.setAlpha(0.45f);
        revokeButton.setOnClickListener(v -> confirmRevokeAuthorization());
        titleView = new TextView(this);
        titleView.setText(expectedOrigin + "  ·  未连接钱包");
        titleView.setTextColor(Color.rgb(30, 50, 75));
        titleView.setTextSize(13);
        titleView.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleParams.leftMargin = 10;
        bar.addView(close, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(backButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(forwardButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(reloadButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(titleView, titleParams);
        bar.addView(revokeButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pageProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100);
        pageProgress.setProgress(0);
        pageProgress.setVisibility(View.GONE);
        root.addView(pageProgress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 3));
        pageStatusView = new TextView(this);
        pageStatusView.setTextColor(Color.rgb(90, 105, 120));
        pageStatusView.setTextSize(12);
        pageStatusView.setPadding(14, 5, 14, 5);
        pageStatusView.setSingleLine(true);
        pageStatusView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pageStatusView.setVisibility(View.GONE);
        root.addView(pageStatusView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        webView = new WebView(this);
        // A fresh, unguessable WebView profile per browser session isolates first-party
        // cookies and DOM storage (including localStorage/IndexedDB) from other DApps.
        // setProfile MUST run before attaching/configuring/navigating this WebView.
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            webView.destroy(); webView = null;
            finish();
            return;
        }
        try {
            dappProfileName = "yujin_dapp_" + PROCESS_PROFILE_EPOCH + "_" + sessionId;
            WebViewCompat.setProfile(webView, dappProfileName);
            dappProfile = ProfileStore.getInstance().getProfile(dappProfileName);
            if (dappProfile == null) throw new IllegalStateException("DApp profile unavailable");
        } catch (Exception e) {
            webView.destroy(); webView = null;
            finish();
            return;
        }
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private boolean configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        dappProfile.getCookieManager().setAcceptThirdPartyCookies(webView, false);
        // DApps must not turn the wallet browser into a generic device-capability bridge.
        // Camera/microphone, geolocation, popups/windows and downloads are denied by default.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                if (pageProgress != null) {
                    pageProgress.setProgress(Math.max(0, Math.min(100, newProgress)));
                    pageProgress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
                }
                if (newProgress >= 100) pageLoading = false;
                updateReloadUi();
            }
            @Override public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                if (view != webView) return;
                pageTitle = sanitizePageTitle(title);
                updateAuthorizationUi();
            }
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                return false;
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                if (request != null) request.deny();
            }
            @Override public boolean onShowFileChooser(WebView view,
                    android.webkit.ValueCallback<android.net.Uri[]> filePathCallback,
                    WebChromeClient.FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                return true;
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, android.webkit.GeolocationPermissions.Callback callback) {
                if (callback != null) callback.invoke(origin, false, false);
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            showBlockedNavigation(url == null ? "" : url);
        });
        webView.setWebViewClient(new WebViewClient() {
            // Navigation callbacks are the interactive guard. Keep both overloads because
            // older Android System WebView builds may dispatch the legacy String callback.
            @Override public boolean shouldOverrideUrlLoading(WebView view, String target) {
                if (!isAllowedUrl(target)) {
                    showBlockedNavigation(target);
                    return true;
                }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return true;
                String target = request.getUrl().toString();
                // The modern callback also reports navigations initiated by child frames.
                // Do not confuse these with ordinary cross-origin images/scripts: this
                // callback is for navigation, so external iframe/form/link targets can be
                // denied without breaking same-origin page subresources.
                if (!isAllowedUrl(target)) {
                    showBlockedNavigation(target);
                    return true;
                }
                return false;
            }
            // A main-frame redirect can be delivered as a network request rather than a
            // user-initiated navigation callback. Fail closed at the request layer too;
            // this callback runs off the UI thread, so it must never show dialogs here.
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                if (request != null && request.isForMainFrame()) {
                    String target = request.getUrl() == null ? "" : request.getUrl().toString();
                    if (!isAllowedUrl(target)) return blockedNavigationResponse();
                }
                return super.shouldInterceptRequest(view, request);
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String target) {
                // Legacy callback does not expose isForMainFrame. Do not use it to block
                // subresources; shouldOverrideUrlLoading(String) and onPageStarted remain
                // the compatibility guards for legacy main-frame navigation.
                return super.shouldInterceptRequest(view, target);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request == null || !request.isForMainFrame() || view != webView) return;
                pageReady = false;
                pageError = "网页加载失败，请检查网络后重试。";
                showPageStatus(pageError, true);
                pageLoading = false;
                if (pageProgress != null) pageProgress.setVisibility(View.GONE);
                updateReloadUi();
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                super.onReceivedHttpError(view, request, response);
                if (request == null || !request.isForMainFrame() || view != webView || response == null) return;
                int code = response.getStatusCode();
                if (code >= 400) {
                    pageError = code == 404 ? "网页不存在（HTTP 404）。" : "网页服务器返回错误（HTTP " + code + "）。";
                    showPageStatus(pageError, true);
                }
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                if (handler != null) handler.cancel();
                revokeAndFinish("TLS 证书验证失败，已阻止 DApp 加载。");
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                // The renderer for this WebView is gone; revoke the session immediately and
                // report the event as handled so WebView does not attempt to reuse the dead renderer.
                revokeAndFinish("DApp WebView 渲染进程异常退出，已终止当前会话。");
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                // Close the bridge before invalidating outstanding work. WebView callbacks
                // can be queued across a same-origin navigation; origin equality alone does
                // not distinguish the old document from the replacement document.
                pageReady = false;
                pageLoading = true;
                pageError = "";
                pageTitle = "";
                updateAuthorizationUi();
                showPageStatus("正在加载网页…", false);
                updateReloadUi();
                if (pageProgress != null) { pageProgress.setProgress(0); pageProgress.setVisibility(View.VISIBLE); }
                updateNavigationUi();
                if (!isAllowedUrl(url)) {
                    revokeAndFinish("DApp origin changed");
                    return;
                }
                // A same-origin reload/navigation creates a new JavaScript document. Never let
                // callbacks created by the previous document survive into that new document.
                if (mainFrameStarted) {
                    invalidatePendingRpc();
                    clearPendingTransactions("DApp page navigated or reloaded");
                    clearPendingConnects("DApp page navigated or reloaded");
                }
                mainFrameStarted = true;
                updateAuthorizationUi();
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (view != webView || !isCurrentActivityForSession()) return;
                if (!isAllowedUrl(url)) {
                    pageReady = false;
                    revokeAndFinish("DApp origin changed");
                    return;
                }
                pageReady = true;
                pageLoading = false;
                if (pageProgress != null) pageProgress.setVisibility(View.GONE);
                if (pageError.isEmpty()) showPageStatus("", false);
                updateReloadUi();
                updateNavigationUi();
            }
        });

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) ||
            !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            revokeAndFinish("当前 Android System WebView 不支持安全消息桥，请更新 WebView 后重试。");
            return false;
        }
        Set<String> allowedOrigins = new HashSet<>();
        allowedOrigins.add(expectedOrigin);
        try {
            WebViewCompat.addWebMessageListener(webView, "yujinDappBridge", allowedOrigins,
                (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                    // Bind every callback to the currently registered Activity/WebView as well
                    // as the exact top-frame origin. A replaced Activity or a callback queued
                    // during document transition must never reach the wallet protocol handler.
                    if (view != webView || !isCurrentActivityForSession() || !pageReady ||
                        !isMainFrame || sourceOrigin == null ||
                        !expectedOrigin.equals(normalizeOrigin(sourceOrigin.toString()))) return;
                    handleMessage(message, replyProxy);
                });
            WebViewCompat.addDocumentStartJavaScript(webView, buildProviderScript(), allowedOrigins);
        } catch (Exception e) {
            revokeAndFinish("安全消息桥初始化失败，已阻止加载 DApp。");
            return false;
        }
        return true;
    }

    private String buildProviderScript() {
        String n = JSONObject.toJSONString(nonce);
        return "(function(){'use strict';if(window.top!==window||window.ethereum||!window.yujinDappBridge)return;" +
            "const nonce=" + n + ",chainId=" + JSONObject.toJSONString("0x" + new java.math.BigInteger(chainId).toString(16)) + ",pending=new Map(),listeners=new Map();let seq=0,bridgeConnected=true,connectedEventSent=false,lastAccounts=null;" +
            "function emit(name,value){const list=listeners.get(name);if(!list)return;list.slice().forEach(fn=>{try{fn(value)}catch(e){}})}" +
            "function add(name,fn){if(typeof name!=='string'||typeof fn!=='function')return this;const list=listeners.get(name)||[];if(!list.includes(fn))list.push(fn);listeners.set(name,list);return this;}" +
            "function remove(name,fn){const list=listeners.get(name);if(!list)return this;const next=list.filter(x=>x!==fn);if(next.length)listeners.set(name,next);else listeners.delete(name);return this;}" +
            "function rejectPending(error){for(const [id,p] of pending){clearTimeout(p.timer);p.reject(error);pending.delete(id);}}" +
            "window.yujinDappBridge.onmessage=function(ev){let m;try{m=JSON.parse(ev.data)}catch(e){return;}" +
            "if(!m||typeof m.id!=='string')return;const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);" +
            "if(m.error){const e=new Error(m.error.message||'Request rejected');e.code=m.error.code||-32000;p.reject(e)}else{" +
            "if(p.method==='eth_requestAccounts'){const accounts=Array.isArray(m.result)?m.result:[];if(!connectedEventSent){connectedEventSent=true;emit('connect',{chainId:chainId});}if(lastAccounts===null||JSON.stringify(lastAccounts)!==JSON.stringify(accounts)){lastAccounts=accounts.slice();emit('accountsChanged',accounts);}}p.resolve(m.result);}};" +
            "const provider={isYujin:true,isMetaMask:false,request:function(args){return new Promise((resolve,reject)=>{" +
            "if(!bridgeConnected||!window.yujinDappBridge){const e=new Error('Provider disconnected');e.code=4900;reject(e);return;}" +
            "if(!args||typeof args!=='object'||Array.isArray(args)||typeof args.method!=='string'||!args.method||Object.keys(args).some(k=>k!=='method'&&k!=='params')||(args.params!==undefined&&!Array.isArray(args.params))){const e=new Error('Invalid request');e.code=-32600;reject(e);return;}" +
            "const id='yj_'+Date.now().toString(36)+'_'+(++seq).toString(36)+'_'+Math.random().toString(36).slice(2,8);" +
            "const entry={resolve:resolve,reject:reject,method:args.method,timer:null};entry.timer=setTimeout(()=>{if(pending.delete(id)){const e=new Error('Request timeout');e.code=-32000;reject(e)}},90000);pending.set(id,entry);" +
            "try{window.yujinDappBridge.postMessage(JSON.stringify({v:1,id:id,method:args.method,params:Array.isArray(args.params)?args.params:[],nonce:nonce,ts:Date.now()}));}" +
            "catch(e){pending.delete(id);clearTimeout(entry.timer);reject(e);}});}," +
            "on:add,addListener:add,once:function(n,f){if(typeof f!=='function')return this;const self=this;function onceListener(v){self.removeListener(n,onceListener);f(v)}return add(n,onceListener);}," +
            "removeListener:remove,off:remove,removeAllListeners:function(n){if(n===undefined)listeners.clear();else listeners.delete(n);return this;}," +
            "listenerCount:function(n){return (listeners.get(n)||[]).length;},listeners:function(n){return (listeners.get(n)||[]).slice();}," +
            "__yujinEmit:function(n,v){emit(n,v);},isConnected:function(){return bridgeConnected&&!!window.yujinDappBridge;}};" +
            "Object.defineProperty(window,'ethereum',{value:provider,configurable:false,writable:false});" +
            "})();";
    }

    // Parse protocol integers without truncating fractional values or overflowing long.
    // JSONObject may expose JSON numbers as Integer, Long, BigInteger, or BigDecimal.
    private static Long exactLong(Object value) {
        if (!(value instanceof Number)) return null;
        try {
            java.math.BigInteger integer = new java.math.BigDecimal(value.toString()).toBigIntegerExact();
            if (integer.compareTo(java.math.BigInteger.valueOf(Long.MIN_VALUE)) < 0 ||
                integer.compareTo(java.math.BigInteger.valueOf(Long.MAX_VALUE)) > 0) return null;
            return Long.valueOf(integer.longValueExact());
        } catch (Exception e) {
            return null;
        }
    }

    private void handleMessage(WebMessageCompat message, JavaScriptReplyProxy reply) {
        if (!pageReady || isFinishing() || isDestroyed() || !isCurrentActivityForSession()) return;
        String raw = message == null ? null : message.getData();
        if (raw == null || raw.length() == 0 || raw.length() > MAX_MESSAGE) return;
        JSONObject msg;
        try { msg = JSON.parseObject(raw); } catch (Exception e) { return; }
        if (msg == null || (msg.size() != 5 && msg.size() != 6) || !msg.containsKey("v") || !msg.containsKey("id") ||
            !msg.containsKey("method") || !msg.containsKey("nonce") || !msg.containsKey("ts") ||
            (msg.size() == 6 && !msg.containsKey("params"))) return;
        Long version = exactLong(msg.get("v"));
        Long timestamp = exactLong(msg.get("ts"));
        if (version == null || version.longValue() != 1L ||
            !(msg.get("id") instanceof String) || !(msg.get("method") instanceof String) ||
            !(msg.get("nonce") instanceof String) || timestamp == null ||
            !nonce.equals(msg.getString("nonce"))) return;
        String id = msg.getString("id");
        String method = msg.getString("method");
        long ts = timestamp.longValue();
        long now = System.currentTimeMillis();
        if (id == null || !id.matches("[A-Za-z0-9_-]{8,64}") || ts < now - MAX_SKEW_MS || ts > now + MAX_SKEW_MS || seenIds.contains(id)) return;
        if (requestCount >= MAX_REQUESTS) { sendError(reply, id, -32000, "Session request limit reached"); return; }
        seenIds.add(id); requestCount++;
        JSONArray params = msg.getJSONArray("params");
        if (params == null) params = new JSONArray();
        // Methods that do not take parameters must reject unexpected values instead of
        // silently ignoring attacker-controlled arguments.
        if ("ping".equals(method) || "eth_chainId".equals(method) ||
            "net_version".equals(method) || "eth_accounts".equals(method) ||
            "eth_requestAccounts".equals(method)) {
            if (!params.isEmpty()) { sendError(reply, id, -32602, "This method does not accept parameters"); return; }
        }
        if ("ping".equals(method)) { sendResult(reply, id, "pong"); return; }
        if ("eth_chainId".equals(method)) { sendResult(reply, id, "0x" + new java.math.BigInteger(chainId).toString(16)); return; }
        if ("net_version".equals(method)) { sendResult(reply, id, chainId); return; }
        if ("eth_accounts".equals(method)) {
            JSONArray a = new JSONArray(); if (!approvedAccount.isEmpty()) a.add(approvedAccount);
            sendResult(reply, id, a); return;
        }
        if ("eth_requestAccounts".equals(method)) {
            if (!approvedAccount.isEmpty()) { JSONArray a = new JSONArray(); a.add(approvedAccount); sendResult(reply, id, a); return; }
            requestAccountApproval(id, reply); return;
        }
        // R21: forward a transaction request only as an untrusted preview event.
        // The web page receives an immediate 4200 rejection; no signing/broadcast path exists.
        if ("eth_sendTransaction".equals(method)) {
            if (approvedAccount.isEmpty()) { sendError(reply, id, 4100, "Connect and authorize an account before requesting a transaction"); return; }
            if (params.size() != 1 || !(params.get(0) instanceof JSONObject)) {
                sendError(reply, id, -32602, "eth_sendTransaction requires exactly one transaction object"); return;
            }
            final String pendingKey = sessionId + ":" + id;
            final PendingTransaction pending;
            synchronized (PENDING_TRANSACTION_LOCK) {
                int sessionPending = 0;
                for (PendingTransaction existing : PENDING_TRANSACTIONS.values()) {
                    if (sessionId.equals(existing.sessionId)) sessionPending++;
                }
                if (PENDING_TRANSACTIONS.size() >= MAX_PENDING_TRANSACTIONS ||
                    sessionPending >= MAX_PENDING_TRANSACTIONS_PER_SESSION ||
                    PENDING_TRANSACTIONS.containsKey(pendingKey)) {
                    sendError(reply, id, -32005, "Too many pending transaction requests"); return;
                }
                Runnable timeout = () -> {
                    PendingTransaction expired = PENDING_TRANSACTIONS.remove(pendingKey);
                    if (expired != null) postError(expired.reply, expired.requestId, 4001, "Transaction request timed out");
                };
                pending = new PendingTransaction(this, reply, sessionId, id,
                    expectedOrigin, approvedAccount, chainId, timeout);
                PENDING_TRANSACTIONS.put(pendingKey, pending);
            }
            if (!handler.postDelayed(pending.timeout, TRANSACTION_PREVIEW_TIMEOUT_MS)) {
                PENDING_TRANSACTIONS.remove(pendingKey, pending);
                sendError(reply, id, -32000, "Unable to schedule transaction request timeout");
                return;
            }
            JSONObject event = new JSONObject();
            event.put("type", "transaction_preview_request");
            event.put("sessionId", sessionId);
            event.put("requestId", id);
            event.put("origin", expectedOrigin);
            event.put("chainId", chainId);
            event.put("chainName", chainName);
            event.put("authorizedAccount", approvedAccount);
            event.put("params", params);
            DappBridgeModule.emit(sessionId, event);
            return;
        }
        if (!isReadOnlyRpcMethod(method) || !validRpcParams(method, params)) {
            sendError(reply, id, 4200, "Unsupported or invalid read-only RPC method. Signing and write methods are disabled.");
            return;
        }
        if (pendingRpc >= 4) { sendError(reply, id, -32005, "Too many pending read-only requests"); return; }
        pendingRpc++;
        final long requestEpoch = rpcEpoch;
        final String requestSession = sessionId;
        final JSONArray rpcParams = params;
        try {
            RPC_EXECUTOR.execute(() -> {
                JSONObject result = performRpc(method, rpcParams);
                handler.post(() -> {
                    if (requestEpoch != rpcEpoch || !requestSession.equals(sessionId) ||
                        isFinishing() || isDestroyed() || !isCurrentActivityForSession()) return;
                    pendingRpc = Math.max(0, pendingRpc - 1);
                    if (result == null) sendError(reply, id, -32000, "Read-only RPC request failed");
                    else if (result.containsKey("error")) sendError(reply, id, -32000, "RPC endpoint returned an error");
                    else sendResult(reply, id, result.get("result"));
                });
            });
        } catch (RejectedExecutionException e) {
            // Global worker/queue capacity is exhausted. Fail this request immediately;
            // never let a DApp grow an unbounded process-wide RPC backlog.
            pendingRpc = Math.max(0, pendingRpc - 1);
            sendError(reply, id, -32005, "DApp read-only RPC capacity is busy; retry later");
        }
    }

    private boolean isCurrentActivityForSession() {
        WeakReference<DappBrowserActivity> ref = ACTIVITIES.get(sessionId);
        return ref != null && ref.get() == this;
    }

    private void invalidatePendingRpc() {
        rpcEpoch++;
        pendingRpc = 0;
    }

    private boolean isReadOnlyRpcMethod(String method) {
        return "eth_blockNumber".equals(method) || "eth_gasPrice".equals(method) ||
            "eth_getBalance".equals(method) || "eth_getTransactionCount".equals(method) ||
            "eth_getCode".equals(method) || "eth_call".equals(method) ||
            "eth_getBlockByNumber".equals(method) || "eth_getTransactionByHash".equals(method) ||
            "eth_getTransactionReceipt".equals(method) || "eth_estimateGas".equals(method) ||
            "eth_feeHistory".equals(method);
    }

    private boolean validRpcParams(String method, JSONArray p) {
        if (p == null) return false;
        if ("eth_blockNumber".equals(method) || "eth_gasPrice".equals(method)) return p.isEmpty();
        if ("eth_getBalance".equals(method) || "eth_getTransactionCount".equals(method) || "eth_getCode".equals(method))
            return p.size() == 2 && isAddress(p.get(0)) && isBlockTag(p.get(1));
        if ("eth_getBlockByNumber".equals(method))
            return p.size() == 2 && isBlockTag(p.get(0)) && p.get(1) instanceof Boolean;
        if ("eth_getTransactionByHash".equals(method) || "eth_getTransactionReceipt".equals(method))
            return p.size() == 1 && p.get(0) instanceof String && ((String)p.get(0)).matches("0x[0-9a-fA-F]{64}");
        if ("eth_call".equals(method)) return p.size() == 2 && validCallObject(p.get(0)) && isBlockTag(p.get(1));
        if ("eth_estimateGas".equals(method))
            return (p.size() == 1 && validCallObject(p.get(0))) ||
                (p.size() == 2 && validCallObject(p.get(0)) && isBlockTag(p.get(1)));
        if ("eth_feeHistory".equals(method)) return validFeeHistoryParams(p);
        return false;
    }

    private boolean validFeeHistoryParams(JSONArray p) {
        if (p.size() < 2 || p.size() > 3) return false;
        Object countValue = p.get(0);
        if (!(countValue instanceof String)) return false;
        String countHex = (String)countValue;
        if (!countHex.matches("0x[1-9a-fA-F][0-9a-fA-F]?")) return false;
        int count;
        try { count = Integer.parseInt(countHex.substring(2), 16); } catch (Exception e) { return false; }
        if (count < 1 || count > 20 || !isBlockTag(p.get(1))) return false;
        if (p.size() == 2) return true;
        Object rewardValue = p.get(2);
        if (!(rewardValue instanceof JSONArray)) return false;
        JSONArray rewards = (JSONArray)rewardValue;
        if (rewards.size() > 5) return false;
        double previous = -1.0;
        for (Object item : rewards) {
            if (!(item instanceof Number)) return false;
            double value = ((Number)item).doubleValue();
            if (Double.isNaN(value) || Double.isInfinite(value) || value < 0.0 || value > 100.0 || value < previous) return false;
            previous = value;
        }
        return true;
    }

    private boolean validCallObject(Object value) {
        if (!(value instanceof JSONObject)) return false;
        JSONObject tx = (JSONObject)value;
        if (tx.isEmpty() || tx.size() > 8) return false;
        Set<String> allowed = new HashSet<>();
        allowed.add("from"); allowed.add("to"); allowed.add("gas"); allowed.add("gasPrice");
        allowed.add("value"); allowed.add("data"); allowed.add("input");
        for (String key : tx.keySet()) {
            if (!allowed.contains(key)) return false;
            Object v = tx.get(key);
            if (!(v instanceof String)) return false;
            String x = (String)v;
            if (("from".equals(key) || "to".equals(key)) && !x.matches("0x[0-9a-fA-F]{40}")) return false;
            if (("gas".equals(key) || "gasPrice".equals(key) || "value".equals(key)) && !x.matches("0x[0-9a-fA-F]{1,64}")) return false;
            if (("data".equals(key) || "input".equals(key)) && (!x.matches("0x(?:[0-9a-fA-F]{2}){0,65536}"))) return false;
        }
        return tx.containsKey("to") && !(tx.containsKey("data") && tx.containsKey("input"));
    }

    private boolean isAddress(Object v) { return v instanceof String && ((String)v).matches("0x[0-9a-fA-F]{40}"); }
    private boolean isBlockTag(Object v) {
        return v instanceof String && (((String)v).matches("0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,15})") ||
            "latest".equals(v) || "earliest".equals(v) || "pending".equals(v) || "safe".equals(v) || "finalized".equals(v));
    }

    // Re-check the configured network immediately before every read-only request.
    // This is a consistency guard against stale/misrouted RPC endpoints, not a proof that
    // a Byzantine endpoint is returning truthful chain data.
    private JSONObject performRpc(String method, JSONArray params) {
        if ("eth_chainId".equals(method)) return performRpcHttp(method, params);
        JSONObject network = performRpcHttp("eth_chainId", new JSONArray());
        if (network == null || !isHexQuantity(network.get("result"))) return null;
        String expectedChain = "0x" + new java.math.BigInteger(chainId).toString(16);
        if (!expectedChain.equalsIgnoreCase(network.getString("result"))) return null;
        // Bind mined-state account reads (balance and nonce) to one observed block identity.
        // For pending, preserve the endpoint's pending-state semantics and do not pretend
        // it belongs to a mined block. This is a race detector, not an account-state proof.
        JSONObject accountStateSnapshot = null;
        if (("eth_getBalance".equals(method) || "eth_getTransactionCount".equals(method)) &&
            params != null && params.size() == 2 && !"pending".equals(params.get(1))) {
            accountStateSnapshot = readBlockSnapshot((String) params.get(1));
            if (accountStateSnapshot == null) return null;
        }
        JSONObject response = performRpcHttp(method, params);
        if (response == null || !isRpcResultConsistent(method, params, response)) return null;
        if (accountStateSnapshot != null &&
            !isAccountStateSnapshotStable((String) params.get(1), accountStateSnapshot)) return null;
        if ("eth_getBlockByNumber".equals(method) && !isBlockParentConsistent(params, response)) return null;
        // safe/finalized are passed through only when the endpoint explicitly supports them.
        // Never silently substitute latest: that would misrepresent finality to the DApp.
        if ("eth_getBlockByNumber".equals(method) && !isFinalityTagConsistent(params, response)) return null;
        // A receipt can become stale while its transaction and containing block are being
        // cross-checked. Re-read it and compare inclusion identity before returning it.
        // This narrows the reorg race window; one RPC endpoint still cannot prove finality.
        if ("eth_getTransactionReceipt".equals(method) &&
            response.get("result") instanceof JSONObject &&
            !isReceiptStableAtReadTime((String) params.get(0), (JSONObject) response.get("result"))) return null;
        return response;
    }

    // Read the concrete block identity behind a state tag without recursively invoking
    // performRpc. The result is only a same-endpoint snapshot anchor, not a state proof.
    private JSONObject readBlockSnapshot(String tag) {
        try {
            JSONArray blockParams = new JSONArray();
            blockParams.add(tag);
            blockParams.add(false);
            JSONObject blockResponse = performRpcHttp("eth_getBlockByNumber", blockParams);
            if (blockResponse == null || blockResponse.containsKey("error") ||
                !(blockResponse.get("result") instanceof JSONObject)) return null;
            JSONObject block = (JSONObject) blockResponse.get("result");
            if (!isHexQuantity(block.get("number")) || !isHash(block.get("hash")) ||
                !isHash(block.get("parentHash"))) return null;
            if (tag.matches("0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,15})") &&
                !tag.equalsIgnoreCase(block.getString("number"))) return null;
            return block;
        } catch (Exception e) { return null; }
    }

    // Re-read the same tag after a mined-state balance/nonce query. A changed block
    // identity means the account-state response may have raced a reorg or moving tag.
    private boolean isAccountStateSnapshotStable(String tag, JSONObject first) {
        JSONObject second = readBlockSnapshot(tag);
        return second != null && first.getString("number").equalsIgnoreCase(second.getString("number")) &&
            first.getString("hash").equalsIgnoreCase(second.getString("hash")) &&
            first.getString("parentHash").equalsIgnoreCase(second.getString("parentHash"));
    }

    // Shape validation alone cannot bind a valid-looking response to the requested object.
    // Enforce request/result identity where JSON-RPC provides an unambiguous identifier.
    private boolean isRpcResultConsistent(String method, JSONArray params, JSONObject response) {
        if (!response.containsKey("result") || response.get("result") == null) return true;
        Object result = response.get("result");
        if ("eth_getTransactionByHash".equals(method)) {
            if (!(result instanceof JSONObject)) return false;
            JSONObject tx = (JSONObject) result;
            return ((String) params.get(0)).equalsIgnoreCase(tx.getString("hash")) &&
                isIncludedObjectBlockConsistent(tx, false);
        }
        if ("eth_getTransactionReceipt".equals(method)) {
            if (!(result instanceof JSONObject)) return false;
            JSONObject receipt = (JSONObject) result;
            return ((String) params.get(0)).equalsIgnoreCase(receipt.getString("transactionHash")) &&
                isIncludedObjectBlockConsistent(receipt, true) &&
                isReceiptTransactionConsistent(receipt, (String) params.get(0));
        }
        if ("eth_getBlockByNumber".equals(method) && result instanceof JSONObject) {
            JSONObject block = (JSONObject) result;
            String requested = (String) params.get(0);
            Object number = block.get("number");
            if (!isHexQuantity(number) || !isHash(block.get("hash")) || !isHash(block.get("parentHash"))) return false;
            if (requested.matches("0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,15})")) {
                try {
                    java.math.BigInteger expected = new java.math.BigInteger(requested.substring(2), 16);
                    java.math.BigInteger actual = new java.math.BigInteger(((String) number).substring(2), 16);
                    if (!expected.equals(actual)) return false;
                } catch (Exception e) { return false; }
            }
        }
        return true;
    }

    // Bind mined transactions and receipts to the block actually returned by this RPC.
    // Pending transactions may omit both inclusion fields; partial or malformed inclusion
    // metadata is rejected. This is endpoint consistency, not cryptographic finality.
    private boolean isIncludedObjectBlockConsistent(JSONObject included, boolean requireInclusion) {
        Object blockHashValue = included.get("blockHash");
        Object blockNumberValue = included.get("blockNumber");
        if (blockHashValue == null && blockNumberValue == null) return !requireInclusion;
        if (!isHash(blockHashValue) || !isHexQuantity(blockNumberValue)) return false;
        try {
            JSONArray blockParams = new JSONArray();
            blockParams.add(blockNumberValue);
            blockParams.add(false);
            JSONObject blockResponse = performRpcHttp("eth_getBlockByNumber", blockParams);
            if (blockResponse == null || !(blockResponse.get("result") instanceof JSONObject)) return false;
            JSONObject block = (JSONObject) blockResponse.get("result");
            if (!isValidBlockResult(block)) return false;
            java.math.BigInteger requestedHeight = new java.math.BigInteger(((String) blockNumberValue).substring(2), 16);
            java.math.BigInteger returnedHeight = new java.math.BigInteger(block.getString("number").substring(2), 16);
            if (!requestedHeight.equals(returnedHeight)) return false;
            return ((String) blockHashValue).equalsIgnoreCase(block.getString("hash"));
        } catch (Exception e) { return false; }
    }

    // A receipt and its transaction must agree on inclusion metadata. This catches
    // internally contradictory RPC responses; it does not establish canonicality/finality.
    private boolean isReceiptTransactionConsistent(JSONObject receipt, String requestedHash) {
        try {
            JSONArray txParams = new JSONArray();
            txParams.add(requestedHash);
            JSONObject txResponse = performRpcHttp("eth_getTransactionByHash", txParams);
            if (txResponse == null || !(txResponse.get("result") instanceof JSONObject)) return false;
            JSONObject tx = (JSONObject) txResponse.get("result");
            if (!requestedHash.equalsIgnoreCase(tx.getString("hash"))) return false;
            if (!isHash(tx.get("blockHash")) || !isHexQuantity(tx.get("blockNumber"))) return false;
            if (!receipt.getString("blockHash").equalsIgnoreCase(tx.getString("blockHash"))) return false;
            if (!receipt.getString("blockNumber").equalsIgnoreCase(tx.getString("blockNumber"))) return false;
            Object receiptIndex = receipt.get("transactionIndex");
            Object txIndex = tx.get("transactionIndex");
            if (receiptIndex != null || txIndex != null) {
                if (!isHexQuantity(receiptIndex) || !isHexQuantity(txIndex) ||
                    !new java.math.BigInteger(((String) receiptIndex).substring(2), 16).equals(
                        new java.math.BigInteger(((String) txIndex).substring(2), 16))) return false;
            }
            return true;
        } catch (Exception e) { return false; }
    }

    // Re-read a mined receipt after all inclusion checks to detect a concurrent reorg or
    // inconsistent endpoint response. Also ensure the reported inclusion height is not
    // ahead of the endpoint's current head. This is a race detector, not a confirmation
    // count or a cryptographic/canonical-finality guarantee.
    private boolean isReceiptStableAtReadTime(String requestedHash, JSONObject first) {
        try {
            JSONArray receiptParams = new JSONArray();
            receiptParams.add(requestedHash);
            JSONObject secondResponse = performRpcHttp("eth_getTransactionReceipt", receiptParams);
            if (secondResponse == null || !(secondResponse.get("result") instanceof JSONObject)) return false;
            JSONObject second = (JSONObject) secondResponse.get("result");
            if (!isValidReceiptResult(second) ||
                !requestedHash.equalsIgnoreCase(second.getString("transactionHash")) ||
                !first.getString("blockHash").equalsIgnoreCase(second.getString("blockHash")) ||
                !first.getString("blockNumber").equalsIgnoreCase(second.getString("blockNumber"))) return false;
            Object firstIndex = first.get("transactionIndex");
            Object secondIndex = second.get("transactionIndex");
            if (firstIndex != null || secondIndex != null) {
                if (!isHexQuantity(firstIndex) || !isHexQuantity(secondIndex) ||
                    !firstIndex.toString().equalsIgnoreCase(secondIndex.toString())) return false;
            }
            Object firstStatus = first.get("status");
            Object secondStatus = second.get("status");
            if (firstStatus == null ? secondStatus != null :
                secondStatus == null || !firstStatus.toString().equalsIgnoreCase(secondStatus.toString())) return false;

            JSONObject headResponse = performRpcHttp("eth_blockNumber", new JSONArray());
            if (headResponse == null || !isHexQuantity(headResponse.get("result"))) return false;
            java.math.BigInteger receiptHeight = new java.math.BigInteger(first.getString("blockNumber").substring(2), 16);
            java.math.BigInteger headHeight = new java.math.BigInteger(((String) headResponse.get("result")).substring(2), 16);
            return headHeight.compareTo(receiptHeight) >= 0;
        } catch (Exception e) { return false; }
    }

    // For a concrete non-genesis block, fetch its predecessor from the same configured
    // endpoint and bind parentHash to that predecessor's hash. This detects accidental
    // mixed-fork/inconsistent responses, but is not independent-node or consensus proof.
    private boolean isBlockParentConsistent(JSONArray params, JSONObject response) {
        if (response == null || !(response.get("result") instanceof JSONObject)) return true;
        JSONObject block = (JSONObject) response.get("result");
        Object numberValue = block.get("number");
        if (!isHexQuantity(numberValue) || !isHash(block.get("hash")) || !isHash(block.get("parentHash"))) return false;
        try {
            java.math.BigInteger number = new java.math.BigInteger(((String) numberValue).substring(2), 16);
            if (number.signum() == 0) return true;
            String previousTag = "0x" + number.subtract(java.math.BigInteger.ONE).toString(16);
            JSONArray previousParams = new JSONArray();
            previousParams.add(previousTag);
            previousParams.add(params.get(1));
            JSONObject previousResponse = performRpcHttp("eth_getBlockByNumber", previousParams);
            if (previousResponse == null || !(previousResponse.get("result") instanceof JSONObject)) return false;
            JSONObject previous = (JSONObject) previousResponse.get("result");
            if (!previousTag.equalsIgnoreCase(previous.getString("number"))) return false;
            return block.getString("parentHash").equalsIgnoreCase(previous.getString("hash"));
        } catch (Exception e) { return false; }
    }

    // Validate the height relationship for explicit safe/finalized block tags. An RPC
    // error for an unsupported tag is preserved as an RPC error (no fallback to latest).
    // A returned block below the head is only endpoint consistency, not a cryptographic
    // proof that the endpoint's safe/finalized claim is truthful.
    private boolean isFinalityTagConsistent(JSONArray params, JSONObject response) {
        if (params == null || params.isEmpty()) return false;
        Object tagValue = params.get(0);
        if (!(tagValue instanceof String) ||
            !("safe".equals(tagValue) || "finalized".equals(tagValue))) return true;
        if (response == null || response.containsKey("error")) return true;
        Object result = response.get("result");
        if (result == null) return false;
        if (!(result instanceof JSONObject)) return false;
        JSONObject block = (JSONObject) result;
        if (!isHexQuantity(block.get("number")) || !isHash(block.get("hash")) ||
            !isHash(block.get("parentHash"))) return false;
        try {
            JSONObject headResponse = performRpcHttp("eth_blockNumber", new JSONArray());
            if (headResponse == null || !isHexQuantity(headResponse.get("result"))) return false;
            java.math.BigInteger taggedHeight = new java.math.BigInteger(
                ((String) block.get("number")).substring(2), 16);
            java.math.BigInteger headHeight = new java.math.BigInteger(
                ((String) headResponse.get("result")).substring(2), 16);
            return taggedHeight.compareTo(headHeight) <= 0;
        } catch (Exception e) { return false; }
    }

    private JSONObject performRpcHttp(String method, JSONArray params) {
        try {
            URL endpoint = new URL(rpcUrl);
            if (!"https".equalsIgnoreCase(endpoint.getProtocol()) || endpoint.getHost() == null ||
                endpoint.getUserInfo() != null || endpoint.getPort() > 65535) return null;

            // Resolve once, screen every answer, then pin OkHttp's DNS result to this exact set.
            // OkHttp still connects using the URL hostname, so TLS SNI, certificate hostname
            // verification and the HTTP Host header remain bound to the original DNS name.
            final Set<String> pinnedAddresses = resolvePublicAddresses(endpoint.getHost());
            if (pinnedAddresses.isEmpty()) return null;
            final Map<String, InetAddress> pinnedByText = new HashMap<>();
            for (InetAddress address : InetAddress.getAllByName(endpoint.getHost())) {
                String key = address.getHostAddress().toLowerCase(Locale.ROOT);
                if (pinnedAddresses.contains(key)) pinnedByText.put(key, address);
            }
            if (pinnedByText.size() != pinnedAddresses.size()) return null;
            final String pinnedHost = endpoint.getHost().toLowerCase(Locale.ROOT);
            Dns pinnedDns = hostname -> {
                if (!pinnedHost.equals(hostname.toLowerCase(Locale.ROOT))) throw new UnknownHostException("Unapproved RPC host");
                java.util.List<InetAddress> result = new java.util.ArrayList<>();
                for (String key : pinnedAddresses) {
                    InetAddress address = pinnedByText.get(key);
                    if (address == null) throw new UnknownHostException("Pinned RPC address unavailable");
                    result.add(address);
                }
                return result;
            };
            OkHttpClient client = new OkHttpClient.Builder()
                .dns(pinnedDns)
                .connectionPool(new ConnectionPool(0, 1, java.util.concurrent.TimeUnit.MILLISECONDS))
                .protocols(Collections.singletonList(Protocol.HTTP_1_1))
                .followRedirects(false).followSslRedirects(false)
                .retryOnConnectionFailure(false)
                .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .callTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .build();

            String rpcRequestId = "yjrpc_" + randomHex(12);
            JSONObject rpcRequest = new JSONObject();
            rpcRequest.put("jsonrpc", "2.0"); rpcRequest.put("id", rpcRequestId);
            rpcRequest.put("method", method); rpcRequest.put("params", params);
            byte[] body = rpcRequest.toJSONString().getBytes(StandardCharsets.UTF_8);
            if (body.length > 131072) return null;
            MediaType jsonType = MediaType.parse("application/json; charset=utf-8");
            Request request = new Request.Builder().url(endpoint)
                .header("Accept", "application/json")
                .post(RequestBody.create(body, jsonType)).build();
            try (Response response = client.newCall(request).execute()) {
                // Redirects are deliberately not followed: a 3xx must never change the pinned origin.
                if (!response.isSuccessful() || response.code() >= 300 || response.body() == null) return null;
                ResponseBody responseBody = response.body();
                if (responseBody.contentLength() > MAX_RPC_RESPONSE) return null;
                byte[] bytes;
                try (InputStream in = responseBody.byteStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[4096]; int n; int total = 0;
                    while ((n = in.read(buffer)) != -1) {
                        total += n; if (total > MAX_RPC_RESPONSE) return null;
                        out.write(buffer, 0, n);
                    }
                    bytes = out.toByteArray();
                }
                JSONObject responseJson = JSON.parseObject(new String(bytes, StandardCharsets.UTF_8));
                if (responseJson == null || !"2.0".equals(responseJson.getString("jsonrpc")) ||
                    !rpcRequestId.equals(responseJson.getString("id")) || responseJson.size() != 3 ||
                    (responseJson.containsKey("result") == responseJson.containsKey("error"))) return null;
                if (responseJson.containsKey("error")) {
                    Object errorValue = responseJson.get("error");
                    if (!(errorValue instanceof JSONObject)) return null;
                    JSONObject errorObject = (JSONObject) errorValue;
                    if (!(errorObject.get("code") instanceof Number) ||
                        !(errorObject.get("message") instanceof String) ||
                        ((String) errorObject.get("message")).length() > 512 ||
                        errorObject.size() > 4) return null;
                } else if (!isValidRpcResult(method, responseJson.get("result"))) {
                    // A well-formed JSON-RPC envelope is not enough: reject values that do not
                    // match the method's expected Ethereum JSON-RPC result type.
                    return null;
                }
                return responseJson;
            }
        } catch (Exception e) { return null; }
    }

    private boolean isValidRpcResult(String method, Object value) {
        if ("net_version".equals(method)) return value instanceof String && ((String) value).matches("[0-9]{1,20}");
        if ("eth_chainId".equals(method) || "eth_blockNumber".equals(method) || "eth_gasPrice".equals(method) ||
            "eth_estimateGas".equals(method) || "eth_getBalance".equals(method) ||
            "eth_getTransactionCount".equals(method)) return isHexQuantity(value);
        if ("eth_getCode".equals(method) || "eth_call".equals(method)) return isHexData(value, MAX_RPC_RESPONSE);
        if ("eth_getBlockByNumber".equals(method)) return value == null || isValidBlockResult(value);
        if ("eth_getTransactionByHash".equals(method)) return value == null || isValidTransactionResult(value);
        if ("eth_getTransactionReceipt".equals(method)) return value == null || isValidReceiptResult(value);
        if ("eth_feeHistory".equals(method)) return isValidFeeHistoryResult(value);
        return false;
    }

    private boolean isHexQuantity(Object value) {
        return value instanceof String && ((String) value).matches("0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,63})");
    }

    private boolean isHexData(Object value, int maxBytes) {
        if (!(value instanceof String)) return false;
        String data = (String) value;
        return data.length() >= 2 && data.startsWith("0x") && (data.length() % 2 == 0) &&
            data.length() <= 2L + (long) maxBytes * 2L && data.substring(2).matches("[0-9a-fA-F]*");
    }

    private boolean isHash(Object value) {
        return value instanceof String && ((String) value).matches("0x[0-9a-fA-F]{64}");
    }

    private boolean isValidBlockResult(Object value) {
        if (!(value instanceof JSONObject)) return false;
        JSONObject block = (JSONObject) value;
        Object number = block.get("number");
        Object hash = block.get("hash");
        Object parentHash = block.get("parentHash");
        Object transactions = block.get("transactions");
        if (!isHexQuantity(number) || !isHash(hash) || !isHash(parentHash) ||
            !(transactions instanceof JSONArray)) return false;
        JSONArray txs = (JSONArray) transactions;
        if (txs.size() > 5000) return false;
        for (Object tx : txs) {
            if (tx instanceof String) { if (!isHash(tx)) return false; }
            else if (!isValidTransactionResult(tx)) return false;
        }
        return true;
    }

    private boolean isValidTransactionResult(Object value) {
        if (!(value instanceof JSONObject)) return false;
        JSONObject tx = (JSONObject) value;
        return isHash(tx.get("hash")) && isAddress(tx.get("from")) &&
            (tx.get("to") == null || isAddress(tx.get("to"))) &&
            isHexQuantity(tx.get("nonce")) &&
            (tx.get("blockHash") == null || isHash(tx.get("blockHash"))) &&
            (tx.get("blockNumber") == null || isHexQuantity(tx.get("blockNumber")));
    }

    private boolean isValidReceiptResult(Object value) {
        if (!(value instanceof JSONObject)) return false;
        JSONObject receipt = (JSONObject) value;
        Object logs = receipt.get("logs");
        Object status = receipt.get("status");
        if (!isHash(receipt.get("transactionHash")) || !isHash(receipt.get("blockHash")) ||
            !isHexQuantity(receipt.get("blockNumber")) ||
            !(receipt.get("transactionIndex") == null || isHexQuantity(receipt.get("transactionIndex"))) ||
            !(status == null || isHexQuantity(status)) || !(logs instanceof JSONArray)) return false;
        return ((JSONArray) logs).size() <= 10000;
    }

    private boolean isValidFeeHistoryResult(Object value) {
        if (!(value instanceof JSONObject)) return false;
        JSONObject history = (JSONObject) value;
        Object oldest = history.get("oldestBlock");
        Object baseFees = history.get("baseFeePerGas");
        Object ratios = history.get("gasUsedRatio");
        if (!isHexQuantity(oldest) || !(baseFees instanceof JSONArray) || !(ratios instanceof JSONArray)) return false;
        JSONArray fees = (JSONArray) baseFees;
        JSONArray used = (JSONArray) ratios;
        if (fees.isEmpty() || fees.size() > 22 || used.size() > 20 || fees.size() != used.size() + 1) return false;
        for (Object fee : fees) if (!isHexQuantity(fee)) return false;
        for (Object ratio : used) {
            if (!(ratio instanceof Number)) return false;
            double n = ((Number) ratio).doubleValue();
            if (Double.isNaN(n) || Double.isInfinite(n) || n < 0.0 || n > 1.0) return false;
        }
        Object rewards = history.get("reward");
        if (rewards != null && !(rewards instanceof JSONArray)) return false;
        return true;
    }

    private void verifyRpcChainThenLoad(String startUrl) {
        final String expectedSession = sessionId;
        final long expectedEpoch = rpcEpoch;
        try {
            RPC_EXECUTOR.execute(() -> {
                JSONObject result = performRpc("eth_chainId", new JSONArray());
                String actual = result == null ? "" : result.getString("result");
                String expected = "0x" + new java.math.BigInteger(chainId).toString(16);
                handler.post(() -> {
                    if (isFinishing() || isDestroyed() || !expectedSession.equals(sessionId) ||
                        expectedEpoch != rpcEpoch || !isCurrentActivityForSession()) return;
                    if (!expected.equalsIgnoreCase(actual)) {
                        revokeAndFinish("配置的 RPC 返回 ChainID 与当前钱包网络不一致，已阻止 DApp 连接。请检查网络 RPC 配置。");
                        return;
                    }
                    webView.loadUrl(startUrl);
                });
            });
        } catch (RejectedExecutionException e) {
            revokeAndFinish("当前只读 RPC 服务繁忙，已阻止打开 DApp。请稍后重试。");
        }
    }

    private boolean isValidRpcUrl(String value) {
        try {
            Uri u = Uri.parse(value == null ? "" : value);
            return "https".equalsIgnoreCase(u.getScheme()) && u.getHost() != null && u.getUserInfo() == null &&
                u.getHost().length() <= 253 && !u.getHost().contains(":") && !u.getHost().matches("[0-9.]+");
        } catch (Exception e) { return false; }
    }

    private Set<String> resolvePublicAddresses(String host) {
        try {
            InetAddress[] addresses = InetAddress.getAllByName(host);
            if (addresses == null || addresses.length == 0 || addresses.length > 32) return Collections.emptySet();
            Set<String> result = new HashSet<>();
            for (InetAddress address : addresses) {
                if (!isGloballyRoutableAddress(address)) return Collections.emptySet();
                result.add(address.getHostAddress().toLowerCase(Locale.ROOT));
            }
            return result;
        } catch (Exception e) { return Collections.emptySet(); }
    }

    private boolean isGloballyRoutableAddress(InetAddress address) {
        if (address == null || address.isAnyLocalAddress() || address.isLoopbackAddress() ||
            address.isLinkLocalAddress() || address.isSiteLocalAddress() || address.isMulticastAddress()) return false;
        byte[] b = address.getAddress();
        if (b.length == 4) {
            int x=b[0]&255, y=b[1]&255, z=b[2]&255;
            // Reject special-use, private, documentation, benchmarking, multicast and reserved IPv4.
            if (x==0 || x==10 || x==100&&y>=64&&y<=127 || x==127 || x==169&&y==254 ||
                x==172&&y>=16&&y<=31 || x==192&&y==0 || x==192&&y==0&&z==2 ||
                x==192&&y==88&&z==99 || x==192&&y==168 || x==198&&(y==18||y==19) ||
                x==198&&y==51&&z==100 || x==203&&y==0&&z==113 || x>=224) return false;
            if (x==255&&y==255&&z==255) return false;
            return true;
        }
        if (b.length == 16) {
            int x=b[0]&255, y=b[1]&255;
            // Reject ULA, link-local, multicast, IPv6 documentation and deprecated site-local.
            if ((x&0xfe)==0xfc || x==0xff || x==0xfe&&(y&0xc0)==0x80 ||
                x==0xfe&&(y&0xc0)==0xc0 || x==0x20&&y==0x01&&(b[2]&255)==0x0d&&(b[3]&255)==0xb8) return false;
            // IPv4-mapped and IPv4-compatible IPv6 must be evaluated as IPv4.
            boolean firstTenZero = true;
            for (int i=0;i<10;i++) if (b[i]!=0) firstTenZero=false;
            boolean firstTwelveZero = firstTenZero && b[10]==0 && b[11]==0;
            if (firstTenZero && b[10]==(byte)0xff && b[11]==(byte)0xff || firstTwelveZero) {
                try { return isGloballyRoutableAddress(InetAddress.getByAddress(Arrays.copyOfRange(b,12,16))); }
                catch (Exception e) { return false; }
            }
            // Reject transition/tunnelling ranges whose embedded IPv4 destination is ambiguous.
            if (x==0x20 && y==0x01 && (b[2]&255)==0x00 && (b[3]&255)==0x00) return false; // Teredo
            if (x==0x20 && y==0x02) return false; // 6to4
            if (x==0x00 && y==0x64 && (b[2]&255)==0xff && (b[3]&255)==0x9b) return false; // NAT64
            return true;
        }
        return false;
    }

    private void requestAccountApproval(String requestId, JavaScriptReplyProxy reply) {
        final String key = sessionId + ":" + requestId;
        final PendingConnect pending;
        synchronized (PENDING_CONNECT_LOCK) {
            if (PENDING.size() >= MAX_PENDING_CONNECTS || PENDING.containsKey(key)) {
                sendError(reply, requestId, -32005, "Too many pending connection requests");
                return;
            }
            for (PendingConnect existing : PENDING.values()) {
                if (sessionId.equals(existing.sessionId)) {
                    sendError(reply, requestId, -32002, "A connection approval is already pending");
                    return;
                }
            }
            Runnable timeout = () -> {
                PendingConnect expired = PENDING.remove(key);
                if (expired != null) postError(expired.reply, expired.requestId, 4001, "User rejected or approval timed out");
            };
            pending = new PendingConnect(this, reply, sessionId, requestId,
                expectedOrigin, chainId, timeout);
            PENDING.put(key, pending);
        }
        if (!handler.postDelayed(pending.timeout, CONNECT_TIMEOUT_MS)) {
            PENDING.remove(key, pending);
            sendError(reply, requestId, -32000, "Unable to schedule connection approval timeout");
            return;
        }
        JSONObject event = new JSONObject();
        event.put("type", "connect_request"); event.put("sessionId", sessionId);
        event.put("requestId", requestId); event.put("origin", expectedOrigin);
        event.put("chainId", chainId); event.put("chainName", chainName);
        DappBridgeModule.emit(sessionId, event);
    }

    static boolean resolveConnect(String sessionId, String requestId, boolean approved, String account) {
        PendingConnect p = PENDING.remove(sessionId + ":" + requestId);
        if (p == null) return false;
        DappBrowserActivity a = p.activity.get();
        if (a == null || a.isFinishing() || a.isDestroyed() ||
            !sessionId.equals(p.sessionId) || !sessionId.equals(a.sessionId) ||
            !p.origin.equals(a.expectedOrigin) || !p.chainId.equals(a.chainId) ||
            !a.isCurrentActivityForSession() || !a.approvedAccount.isEmpty()) {
            postError(p.reply, requestId, 4001, "Connection request context changed");
            return true;
        }
        a.handler.removeCallbacks(p.timeout);
        if (!approved || account == null || !account.matches("0x[0-9a-fA-F]{40}")) {
            postError(p.reply, requestId, 4001, "User rejected the request");
            return true;
        }
        a.approvedAccount = account;
        JSONArray accounts = new JSONArray(); accounts.add(account);
        postResult(p.reply, requestId, accounts);
        a.updateAuthorizationUi();
        JSONObject event = new JSONObject(); event.put("type", "account_authorized"); event.put("origin", a.expectedOrigin); event.put("account", account);
        DappBridgeModule.emit(sessionId, event);
        return true;
    }

    static boolean resolveTransactionPreview(String sessionId, String requestId, boolean approved) {
        String key = sessionId + ":" + requestId;
        PendingTransaction p = PENDING_TRANSACTIONS.remove(key);
        if (p == null) return false;
        DappBrowserActivity a = p.activity.get();
        if (a == null || a.isFinishing() || a.isDestroyed() || !p.sessionId.equals(sessionId) ||
            !sessionId.equals(a.sessionId) || !p.origin.equals(a.expectedOrigin) ||
            !p.chainId.equals(a.chainId) || !a.isCurrentActivityForSession() ||
            p.account.isEmpty() || !p.account.equalsIgnoreCase(a.approvedAccount)) {
            postError(p.reply, requestId, 4001, "Transaction request context changed");
            return true;
        }
        a.handler.removeCallbacks(p.timeout);
        // R22 intentionally supports cancellation only. A positive response is rejected until
        // wallet-side fresh nonce/fee resolution, signing, signed-payload verification and broadcast exist.
        postError(p.reply, requestId, approved ? 4200 : 4001,
            approved ? "Transaction signing and broadcast are not enabled" : "User rejected the transaction");
        return true;
    }

    private void clearPendingTransactions(String reason) {
        for (Map.Entry<String, PendingTransaction> entry : new HashMap<>(PENDING_TRANSACTIONS).entrySet()) {
            PendingTransaction p = entry.getValue();
            if (p.activity.get() == this && PENDING_TRANSACTIONS.remove(entry.getKey(), p)) {
                handler.removeCallbacks(p.timeout);
                postError(p.reply, p.requestId, 4001, reason);
            }
        }
    }

    private void clearPendingConnects(String reason) {
        for (Map.Entry<String, PendingConnect> entry : new HashMap<>(PENDING).entrySet()) {
            PendingConnect p = entry.getValue();
            if (p.activity.get() == this && PENDING.remove(entry.getKey(), p)) {
                handler.removeCallbacks(p.timeout);
                postError(p.reply, p.requestId, 4001, reason);
            }
        }
    }

    private void reloadOrStop() {
        if (webView == null) return;
        if (pageLoading) {
            webView.stopLoading();
            pageLoading = false;
            if (pageProgress != null) pageProgress.setVisibility(View.GONE);
        } else {
            String current = webView.getUrl();
            if (current == null || !isAllowedUrl(current)) {
                showBlockedNavigation(current == null ? "" : current);
                return;
            }
            webView.reload();
            pageLoading = true;
            if (pageProgress != null) { pageProgress.setProgress(0); pageProgress.setVisibility(View.VISIBLE); }
        }
        updateReloadUi();
    }

    private void updateReloadUi() {
        if (reloadButton == null) return;
        reloadButton.setText(pageLoading ? "×" : "↻");
        reloadButton.setContentDescription(pageLoading ? "停止加载" : "刷新页面");
        reloadButton.setEnabled(webView != null);
        reloadButton.setAlpha(webView != null ? 1.0f : 0.45f);
    }

    private void navigateBack() {
        if (webView == null || !webView.canGoBack()) return;
        String target = webView.copyBackForwardList().getItemAtIndex(webView.copyBackForwardList().getCurrentIndex() - 1).getUrl();
        if (!isAllowedUrl(target)) { showBlockedNavigation(target); return; }
        webView.goBack();
        updateNavigationUi();
    }

    private void navigateForward() {
        if (webView == null || !webView.canGoForward()) return;
        String target = webView.copyBackForwardList().getItemAtIndex(webView.copyBackForwardList().getCurrentIndex() + 1).getUrl();
        if (!isAllowedUrl(target)) { showBlockedNavigation(target); return; }
        webView.goForward();
        updateNavigationUi();
    }

    private void updateNavigationUi() {
        boolean canBack = webView != null && webView.canGoBack();
        boolean canForward = webView != null && webView.canGoForward();
        if (backButton != null) { backButton.setEnabled(canBack); backButton.setAlpha(canBack ? 1.0f : 0.45f); }
        if (forwardButton != null) { forwardButton.setEnabled(canForward); forwardButton.setAlpha(canForward ? 1.0f : 0.45f); }
    }

    private static String sanitizePageTitle(String title) {
        if (title == null) return "";
        String clean = title.replaceAll("[\\p{Cntrl}]", " ").replaceAll("\\s+", " ").trim();
        if (clean.length() > 80) clean = clean.substring(0, 80);
        return clean;
    }

    private void showPageStatus(String message, boolean isError) {
        if (pageStatusView == null) return;
        String value = message == null ? "" : message.trim();
        pageStatusView.setText(value);
        pageStatusView.setTextColor(isError ? Color.rgb(180, 45, 45) : Color.rgb(90, 105, 120));
        pageStatusView.setVisibility(value.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void updateAuthorizationUi() {
        updateNavigationUi();
        if (titleView != null) {
            String safeTitle = pageTitle.isEmpty() ? expectedOrigin : pageTitle;
            titleView.setText(safeTitle + "  ·  " + expectedOrigin + (approvedAccount.isEmpty() ? "  ·  未连接钱包" : "  ·  已授权账户"));
        }
        if (revokeButton != null) {
            boolean authorized = !approvedAccount.isEmpty();
            revokeButton.setEnabled(authorized);
            revokeButton.setAlpha(authorized ? 1.0f : 0.45f);
        }
    }

    private void confirmRevokeAuthorization() {
        if (approvedAccount.isEmpty()) return;
        new AlertDialog.Builder(this)
            .setTitle("撤销 DApp 账户授权")
            .setMessage("撤销后网站将立即无法再读取钱包地址。若要重新连接，需要再次由你确认。")
            .setNegativeButton("取消", (d, w) -> {})
            .setPositiveButton("确认撤销", (d, w) -> revokeAuthorization())
            .show();
    }

    private void revokeAuthorization() {
        if (approvedAccount.isEmpty()) return;
        clearPendingTransactions("Wallet authorization revoked");
        invalidatePendingRpc();
        approvedAccount = "";
        updateAuthorizationUi();
        // Push the EIP-1193 accountsChanged event into the isolated, origin-bound WebView.
        if (webView != null) {
            webView.evaluateJavascript("if(window.ethereum&&typeof window.ethereum.__yujinEmit==='function'){window.ethereum.__yujinEmit('accountsChanged',[]);}", null);
        }
        JSONObject event = new JSONObject();
        event.put("type", "account_revoked");
        event.put("sessionId", sessionId);
        event.put("origin", expectedOrigin);
        DappBridgeModule.emit(sessionId, event);
    }

    static JSONArray listActiveSessions() {
        JSONArray out = new JSONArray();
        for (Map.Entry<String, WeakReference<DappBrowserActivity>> entry : new HashMap<>(ACTIVITIES).entrySet()) {
            DappBrowserActivity a = entry.getValue() == null ? null : entry.getValue().get();
            if (a == null || a.isFinishing() || a.isDestroyed() || !entry.getKey().equals(a.sessionId)) {
                ACTIVITIES.remove(entry.getKey(), entry.getValue());
                continue;
            }
            JSONObject item = new JSONObject();
            item.put("sessionId", a.sessionId);
            item.put("origin", a.expectedOrigin);
            item.put("chainId", a.chainId);
            item.put("chainName", a.chainName == null ? "" : a.chainName);
            item.put("authorizedAccount", a.approvedAccount == null ? "" : a.approvedAccount);
            item.put("openedAt", a.openedAt);
            out.add(item);
        }
        return out;
    }

    static boolean closeSession(String sessionId) {
        if (sessionId == null || !sessionId.matches("[a-fA-F0-9]{32}")) return false;
        WeakReference<DappBrowserActivity> ref = ACTIVITIES.get(sessionId);
        DappBrowserActivity a = ref == null ? null : ref.get();
        if (a == null || a.isFinishing() || a.isDestroyed()) {
            if (ref != null) ACTIVITIES.remove(sessionId, ref);
            return false;
        }
        a.revokeAuthorization();
        a.finish();
        return true;
    }

    static int closeAllSessions() {
        int closed = 0;
        for (String id : new HashMap<>(ACTIVITIES).keySet()) if (closeSession(id)) closed++;
        return closed;
    }

    private static android.webkit.WebResourceResponse blockedNavigationResponse() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store, no-cache, must-revalidate");
        headers.put("Pragma", "no-cache");
        headers.put("X-Content-Type-Options", "nosniff");
        return new android.webkit.WebResourceResponse(
            "text/plain", "UTF-8", 403, "Blocked by wallet origin policy",
            headers, new ByteArrayInputStream("DApp navigation blocked by origin policy".getBytes(StandardCharsets.UTF_8)));
    }

    private void showBlockedNavigation(String target) {
        new AlertDialog.Builder(this).setTitle("已阻止跨域跳转")
            .setMessage("安全连接会话绑定当前域名，目标地址不属于该域名：\n" + safeText(target) + "\n\n请关闭页面后重新打开并确认新域名。")
            .setPositiveButton("知道了", (d, w) -> {}).show();
    }

    private void revokeAndFinish(String reason) {
        // Fail closed synchronously: SSL/render-process/origin failures can arrive while a
        // document still appears ready. Never leave wallet authority alive while a dialog is
        // waiting for the user to acknowledge the fatal condition.
        pageReady = false;
        if (isFinishing() || securityTerminationRequested) return;
        securityTerminationRequested = true;
        invalidatePendingRpc();
        clearPendingTransactions("DApp security session terminated");
        clearPendingConnects("DApp security session terminated");
        if (!approvedAccount.isEmpty()) revokeAuthorization();
        Runnable show = () -> {
            if (isFinishing() || isDestroyed()) return;
            new AlertDialog.Builder(this).setTitle("DApp 安全连接已终止").setMessage(reason)
                .setPositiveButton("关闭", (d, w) -> finish()).setOnCancelListener(d -> finish()).show();
        };
        if (Looper.myLooper() == Looper.getMainLooper()) show.run();
        else handler.post(show);
    }

    private boolean isAllowedUrl(String value) {
        try {
            Uri u = Uri.parse(value == null ? "" : value);
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getUserInfo() != null) return false;
        } catch (Exception e) { return false; }
        String o = normalizeOrigin(value);
        return !o.isEmpty() && expectedOrigin.equals(o);
    }

    private static String normalizeOrigin(String value) {
        try {
            Uri u = Uri.parse(value == null ? "" : value);
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost() == null || u.getUserInfo() != null) return "";
            String host = u.getHost().toLowerCase(Locale.ROOT);
            int port = u.getPort();
            return "https://" + host + (port == -1 || port == 443 ? "" : ":" + port);
        } catch (Exception e) { return ""; }
    }

    private static String safeText(String value) { return value == null ? "" : value.substring(0, Math.min(value.length(), 256)); }
    static String randomHex(int bytes) {
        byte[] b = new byte[bytes]; new SecureRandom().nextBytes(b);
        StringBuilder s = new StringBuilder(bytes * 2);
        for (byte x : b) s.append(String.format(Locale.ROOT, "%02x", x & 0xff));
        return s.toString();
    }
    private static void sendResult(JavaScriptReplyProxy r, String id, Object result) { JSONObject o = new JSONObject(); o.put("id", id); o.put("result", result); r.postMessage(o.toJSONString()); }
    private static void sendError(JavaScriptReplyProxy r, String id, int code, String message) { postError(r, id, code, message); }
    private static void postResult(JavaScriptReplyProxy r, String id, Object result) { sendResult(r, id, result); }
    private static void postError(JavaScriptReplyProxy r, String id, int code, String message) { JSONObject e = new JSONObject(); e.put("code", code); e.put("message", message); JSONObject o = new JSONObject(); o.put("id", id); o.put("error", e); r.postMessage(o.toJSONString()); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) navigateBack();
        else finish();
    }

    @Override protected void onStop() {
        // A backgrounded native DApp browser must not retain account disclosure
        // authority or unresolved wallet prompts while another app is foregrounded.
        if (!isFinishing() && !isChangingConfigurations()) {
            clearPendingTransactions("DApp browser left foreground");
            clearPendingConnects("DApp browser left foreground");
            invalidatePendingRpc();
            revokeAuthorization();
        }
        super.onStop();
    }

    @Override protected void onDestroy() {
        // Activity destruction is an authority boundary, including configuration changes.
        // Close the bridge before touching registries or pending callbacks: a queued
        // WebMessageListener callback from this instance must fail closed while Android
        // is replacing it with a new Activity for the same logical browser session.
        pageReady = false;
        securityTerminationRequested = true;
        invalidatePendingRpc();
        clearPendingTransactions("DApp session closed");
        for (Map.Entry<String, PendingConnect> e : new HashMap<>(PENDING).entrySet()) {
            PendingConnect p = e.getValue();
            if (p.activity.get() == this) {
                PENDING.remove(e.getKey()); handler.removeCallbacks(p.timeout);
                postError(p.reply, p.requestId, 4001, "DApp session closed");
            }
        }
        // During rotation Android creates a replacement Activity with the same session id.
        // Do not let the outgoing instance remove the replacement's registry/callback.
        WeakReference<DappBrowserActivity> currentRef = ACTIVITIES.get(sessionId);
        if (currentRef != null && currentRef.get() == this) ACTIVITIES.remove(sessionId, currentRef);
        approvedAccount = ""; // Never restore account approval across Activity recreation/process death.
        updateAuthorizationUi();
        if (!isChangingConfigurations()) {
            JSONObject closed = new JSONObject(); closed.put("type", "closed"); closed.put("sessionId", sessionId);
            DappBridgeModule.emit(sessionId, closed);
            DappBridgeModule.forget(sessionId);
        }
        // Keep the profile handle locally until its asynchronous data-deletion callback
        // completes. The WebView must be destroyed first; deleting a live profile can race
        // outstanding renderer writes and ProfileStore.deleteProfile rejects live views.
        final Profile profileToClean = dappProfile;
        final boolean keepProfileForRotation = isChangingConfigurations();
        try {
            destroyDappWebView();
        } finally {
            // Release Activity references even if a vendor WebView implementation throws
            // during teardown. The captured Profile remains alive for asynchronous cleanup.
            dappProfile = null;
            dappProfileName = null;
            if (!keepProfileForRotation && profileToClean != null) {
                clearIsolatedProfileData(profileToClean);
            }
            super.onDestroy();
        }
    }

    /**
     * Tear down the browser bridge and renderer defensively. Vendor WebView providers can
     * throw while a renderer is already gone; one failed cleanup call must not skip destroy().
     */
    private void destroyDappWebView() {
        final WebView target = webView;
        webView = null;
        if (target == null) return;
        try { WebViewCompat.removeWebMessageListener(target, "yujinDappBridge"); } catch (Exception ignored) {}
        try { target.stopLoading(); } catch (Exception ignored) {}
        // Do not navigate to about:blank here: it schedules another document load while
        // the Activity is already being destroyed and can race profile-data deletion.
        try { target.setDownloadListener(null); } catch (Exception ignored) {}
        try { target.setWebChromeClient(null); } catch (Exception ignored) {}
        try { target.clearHistory(); } catch (Exception ignored) {}
        try { target.clearFormData(); } catch (Exception ignored) {}
        try { target.removeAllViews(); } catch (Exception ignored) {}
        try { target.destroy(); } catch (Exception ignored) {}
    }

    /**
     * Clear browsing data only inside this uniquely named DApp profile. The 1.13.0
     * WebStorageCompat API includes cookies, HTTP cache, DOM storage and service workers,
     * and provides a completion callback. Older System WebView providers fall back to
     * profile-scoped cookie/storage cleanup; that fallback cannot guarantee service-worker
     * cache deletion, but never touches the shared Default profile.
     */
    private void clearIsolatedProfileData(@NonNull final Profile profile) {
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DELETE_BROWSING_DATA)) {
                WebStorageCompat.deleteBrowsingData(profile.getWebStorage(), new Runnable() {
                    @Override public void run() {
                        // Do not delete ProfileStore entries here: the Profile object was
                        // loaded in this process and deleteProfile() rejects loaded handles.
                        // Each new session gets a fresh random profile name, so no later
                        // session can reopen this profile even if provider disk cleanup lags.
                    }
                });
                return;
            }
        } catch (Exception ignored) {
            // Fall through to the narrower per-profile fallback below.
        }
        try {
            profile.getCookieManager().removeAllCookies(new android.webkit.ValueCallback<Boolean>() {
                @Override public void onReceiveValue(Boolean ignored) {
                    try { profile.getWebStorage().deleteAllData(); } catch (Exception ignoredStorage) {}
                }
            });
        } catch (Exception ignored) {
            // Best-effort only. Profile isolation still prevents cross-DApp data access.
        }
    }
}
