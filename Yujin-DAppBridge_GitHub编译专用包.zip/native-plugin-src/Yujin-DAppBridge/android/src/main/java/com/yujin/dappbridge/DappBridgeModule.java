package com.yujin.dappbridge;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import io.dcloud.feature.uniapp.annotation.UniJSMethod;
import io.dcloud.feature.uniapp.bridge.UniJSCallback;
import io.dcloud.feature.uniapp.common.UniModule;

/** Uni-app Android module. It never receives private keys or signs transactions. */
public final class DappBridgeModule extends UniModule {
    private static final Map<String, UniJSCallback> CALLBACKS = new ConcurrentHashMap<>();

    @UniJSMethod(uiThread = true)
    public void openBrowser(JSONObject options, UniJSCallback callback) {
        if (!(mUniSDKInstance.getContext() instanceof Activity)) {
            invoke(callback, error("NO_ACTIVITY", "App Activity unavailable"));
            return;
        }
        String url = options == null ? "" : options.getString("url");
        String chainId = options == null ? "" : options.getString("chainId");
        String chainName = options == null ? "" : options.getString("chainName");
        String rpcUrl = options == null ? "" : options.getString("rpcUrl");
        Uri uri;
        Uri rpcUri;
        try { rpcUri = Uri.parse(rpcUrl == null ? "" : rpcUrl); } catch (Exception e) { rpcUri = null; }
        if (rpcUrl == null || rpcUrl.length() == 0 || rpcUrl.length() > 512 || rpcUri == null ||
            !"https".equalsIgnoreCase(rpcUri.getScheme()) || rpcUri.getHost() == null || rpcUri.getUserInfo() != null || isLocalHost(rpcUri.getHost())) {
            invoke(callback, error("RPC_URL_REJECTED", "只读 RPC 必须是有效的公网 HTTPS 地址"));
            return;
        }
        try { uri = Uri.parse(url); } catch (Exception e) { uri = null; }
        if (url == null || url.length() == 0 || url.length() > 2048 || url.matches(".*[\\x00-\\x1f\\x7f].*") ||
            uri == null || !"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null ||
            isLocalHost(uri.getHost())) {
            invoke(callback, error("URL_REJECTED", "Only credential-free HTTPS URLs are supported"));
            return;
        }
        if (chainId == null || !chainId.matches("[1-9][0-9]{0,19}")) {
            invoke(callback, error("CHAIN_INVALID", "Invalid wallet chain id"));
            return;
        }
        String sessionId = DappBrowserActivity.randomHex(16);
        if (callback != null) CALLBACKS.put(sessionId, callback);
        Intent intent = new Intent(mUniSDKInstance.getContext(), DappBrowserActivity.class);
        intent.putExtra("url", url);
        intent.putExtra("origin", uri.getScheme() + "://" + uri.getAuthority());
        intent.putExtra("chainId", chainId);
        intent.putExtra("chainName", chainName == null ? "" : chainName);
        intent.putExtra("rpcUrl", rpcUrl);
        intent.putExtra("sessionId", sessionId);
        try {
            ((Activity) mUniSDKInstance.getContext()).startActivity(intent);
            JSONObject result = new JSONObject();
            result.put("ok", true);
            result.put("sessionId", sessionId);
            result.put("mode", "android-native-origin-bound");
            invokeKeep(callback, result);
        } catch (Exception e) {
            CALLBACKS.remove(sessionId);
            invoke(callback, error("OPEN_FAILED", "Unable to open native DApp browser"));
        }
    }

    @UniJSMethod(uiThread = true)
    public void respondConnect(JSONObject options, UniJSCallback callback) {
        String sessionId = options == null ? "" : options.getString("sessionId");
        String requestId = options == null ? "" : options.getString("requestId");
        boolean approved = options != null && Boolean.TRUE.equals(options.getBoolean("approved"));
        String account = options == null ? "" : options.getString("account");
        if (!DappBrowserActivity.resolveConnect(sessionId, requestId, approved, account)) {
            invoke(callback, error("REQUEST_NOT_FOUND", "Connection request expired or no longer active"));
            return;
        }
        JSONObject result = new JSONObject();
        result.put("ok", true);
        invoke(callback, result);
    }

    @UniJSMethod(uiThread = true)
    public void respondTransactionPreview(JSONObject options, UniJSCallback callback) {
        String sessionId = options == null ? "" : options.getString("sessionId");
        String requestId = options == null ? "" : options.getString("requestId");
        boolean approved = options != null && Boolean.TRUE.equals(options.getBoolean("approved"));
        if (!DappBrowserActivity.resolveTransactionPreview(sessionId, requestId, approved)) {
            invoke(callback, error("REQUEST_NOT_FOUND", "交易请求已超时、撤销或关闭"));
            return;
        }
        JSONObject result = new JSONObject(); result.put("ok", true); invoke(callback, result);
    }

    @UniJSMethod(uiThread = true)
    public void listActiveSessions(JSONObject options, UniJSCallback callback) {
        JSONObject result = new JSONObject();
        result.put("ok", true);
        result.put("sessions", DappBrowserActivity.listActiveSessions());
        invoke(callback, result);
    }

    @UniJSMethod(uiThread = true)
    public void closeBrowser(JSONObject options, UniJSCallback callback) {
        String sessionId = options == null ? "" : options.getString("sessionId");
        boolean closed = DappBrowserActivity.closeSession(sessionId);
        if (closed) CALLBACKS.remove(sessionId);
        JSONObject result = new JSONObject();
        result.put("ok", closed);
        invoke(callback, result);
    }

    @UniJSMethod(uiThread = true)
    public void closeAllBrowsers(JSONObject options, UniJSCallback callback) {
        int closedCount = DappBrowserActivity.closeAllSessions();
        CALLBACKS.clear();
        JSONObject result = new JSONObject();
        result.put("ok", true);
        result.put("closedCount", closedCount);
        invoke(callback, result);
    }

    static void emit(String sessionId, JSONObject event) {
        UniJSCallback cb = CALLBACKS.get(sessionId);
        if (cb != null) {
            try { cb.invokeAndKeepAlive(event); } catch (Exception ignored) { CALLBACKS.remove(sessionId); }
        }
    }

    static void forget(String sessionId) { CALLBACKS.remove(sessionId); }

    private static boolean isLocalHost(String rawHost) {
        String h = rawHost == null ? "" : rawHost.toLowerCase(java.util.Locale.ROOT).replace("[", "").replace("]", "").replaceAll("\\.$", "");
        if (h.isEmpty() || h.equals("localhost") || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
        // The first native release deliberately rejects IPv6 literals until origin canonicalization is device-tested.
        if (h.contains(":")) return true;
        if (h.matches("[0-9]+") || h.matches("0x[0-9a-f]+")) return true;
        if (h.matches("[0-9.]+") && !h.matches("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}")) return true;
        String[] p = h.split("\\.");
        if (p.length != 4) return false;
        try {
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
            if (a < 0 || a > 255 || b < 0 || b > 255) return true;
            int c = Integer.parseInt(p[2]), d = Integer.parseInt(p[3]);
            if (c < 0 || c > 255 || d < 0 || d > 255) return true;
            return a == 0 || a == 10 || a == 127 || (a == 169 && b == 254) ||
                (a == 172 && b >= 16 && b <= 31) || (a == 192 && b == 168) ||
                (a == 100 && b >= 64 && b <= 127) || (a == 192 && b == 0) ||
                (a == 198 && (b == 18 || b == 19)) || a >= 224;
        } catch (Exception e) { return true; }
    }

    private static JSONObject error(String code, String message) {
        JSONObject result = new JSONObject();
        result.put("ok", false);
        result.put("code", code);
        result.put("message", message);
        return result;
    }

    private static void invoke(UniJSCallback callback, JSONObject result) {
        if (callback != null) callback.invoke(result);
    }

    private static void invokeKeep(UniJSCallback callback, JSONObject result) {
        if (callback != null) callback.invokeAndKeepAlive(result);
    }
}
